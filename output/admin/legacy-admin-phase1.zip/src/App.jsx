import React, { useState, useMemo, useEffect } from 'react';
import { 
  LayoutDashboard, Users, GraduationCap, Briefcase, AlertTriangle, 
  Megaphone, Flag, Settings, Search, Bell, Menu, X, TrendingUp, 
  TrendingDown, CheckCircle, Clock, ChevronDown, Activity, Sun, Moon, 
  Download, Filter, Building, Calendar, Shield, CheckCircle2, Eye, 
  Ban, FileText, Check, Image as ImageIcon, MapPin, Link2, Droplet, 
  HeartPulse, Phone, Hospital, Plus, Play, Pause, Trash2, Edit3, 
  MonitorUp, Upload, CalendarDays, BarChart3, PieChart
} from 'lucide-react';

// --- MOCK DATA ---
const kpis = [
  { title: "Total Users", value: "12,450", icon: Users, trend: "+12% this month", positive: true },
  { title: "Verified Alumni", value: "8,230", icon: GraduationCap, trend: "+5% this month", positive: true },
  { title: "Pending Job Approvals", value: "24", icon: Briefcase, trend: "Requires attention", positive: false },
  { title: "Active Emergency Requests", value: "2", icon: AlertTriangle, trend: "High priority", positive: false, alert: true },
  { title: "Pending Verifications", value: "156", icon: Clock, trend: "Normal queue", positive: true },
  { title: "Active Donors", value: "1,042", icon: Activity, trend: "+2% this week", positive: true },
  { title: "Suspended Users", value: "18", icon: Flag, trend: "-3 since last week", positive: true },
  { title: "Active Ads", value: "45", icon: Megaphone, trend: "Steady", positive: true }
];

const pendingActions = [
  { id: 1, title: "Alumni certificate pending", subtitle: "Batch 2019 – uploaded today", type: "Alumni", badgeColor: "bg-blue-100 text-blue-800 dark:bg-blue-500/20 dark:text-blue-300", time: "10 mins ago" },
  { id: 2, title: "Senior Software Engineer at TechCorp", subtitle: "Job posting requires approval", type: "Job", badgeColor: "bg-purple-100 text-purple-800 dark:bg-purple-500/20 dark:text-purple-300", time: "1 hour ago" },
  { id: 3, title: "Medical support needed for student", subtitle: "Reported by user @rahim_nsu", type: "Emergency", badgeColor: "bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-300", time: "2 hours ago" },
  { id: 4, title: "Spring Semester Campaign", subtitle: "Ad campaign expiring in 24 hours", type: "Ad", badgeColor: "bg-yellow-100 text-yellow-800 dark:bg-yellow-500/20 dark:text-yellow-300", time: "5 hours ago" },
];

const recentActivity = [
  { id: 1, text: "New user Sarah Khan joined", time: "5 mins ago", icon: Users, color: "text-green-500 bg-green-50 dark:bg-green-500/20 dark:text-green-400" },
  { id: 2, text: "New job 'Product Designer' posted", time: "25 mins ago", icon: Briefcase, color: "text-blue-500 bg-blue-50 dark:bg-blue-500/20 dark:text-blue-400" },
  { id: 3, text: "Emergency request resolved", time: "1 hour ago", icon: CheckCircle, color: "text-emerald-500 bg-emerald-50 dark:bg-emerald-500/20 dark:text-emerald-400" },
  { id: 4, text: "New donor registered: Ahmed Foundation", time: "3 hours ago", icon: Activity, color: "text-purple-500 bg-purple-50 dark:bg-purple-500/20 dark:text-purple-400" },
];

const mockUsers = [
  { id: 1, name: "Sarah Khan", email: "sarah.k@northsouth.edu", avatar: "https://i.pravatar.cc/150?u=1", role: "Student", department: "Computer Science", batch: "2021", status: "Active", verification: "Verified", joinDate: "Oct 12, 2023" },
  { id: 2, name: "Rafiq Ahmed", email: "rafiq.a@alumni.northsouth.edu", avatar: "https://i.pravatar.cc/150?u=2", role: "Alumni", department: "Business Admin", batch: "2018", status: "Pending", verification: "Unverified", joinDate: "Nov 05, 2023" },
  { id: 3, name: "Dr. Hasan Mahmud", email: "hasan.m@northsouth.edu", avatar: "https://i.pravatar.cc/150?u=3", role: "Faculty", department: "Electrical Eng", batch: null, status: "Active", verification: "Verified", joinDate: "Jan 10, 2022" },
  { id: 4, name: "Tariq Rahman", email: "tariq.r@northsouth.edu", avatar: "https://i.pravatar.cc/150?u=4", role: "Student", department: "Architecture", batch: "2022", status: "Suspended", verification: "Verified", joinDate: "Mar 22, 2023" },
  { id: 5, name: "Nadia Islam", email: "nadia.i@alumni.northsouth.edu", avatar: "https://i.pravatar.cc/150?u=5", role: "Alumni", department: "Economics", batch: "2020", status: "Active", verification: "Verified", joinDate: "Feb 14, 2024" },
  { id: 6, name: "Fahim R.", email: "admin@northsouth.edu", avatar: "https://i.pravatar.cc/150?u=admin", role: "Admin", department: "IT Support", batch: null, status: "Active", verification: "Verified", joinDate: "Aug 01, 2020" },
  { id: 7, name: "Ayesha Siddiqa", email: "ayesha.s@northsouth.edu", avatar: "https://i.pravatar.cc/150?u=7", role: "Student", department: "Pharmacy", batch: "2023", status: "Active", verification: "Unverified", joinDate: "Jan 05, 2024" },
];

const mockVerifications = [
  { id: 101, name: "Rafiq Ahmed", email: "rafiq.a@alumni.northsouth.edu", avatar: "https://i.pravatar.cc/150?u=2", role: "Alumni", department: "Business Admin", batch: "2018", status: "Pending", submitDate: "Nov 05, 2023, 10:30 AM", certImg: "https://images.unsplash.com/photo-1589330694653-efa6477e0fa0?auto=format&fit=crop&q=80&w=800" },
  { id: 102, name: "Nadia Islam", email: "nadia.i@alumni.northsouth.edu", avatar: "https://i.pravatar.cc/150?u=5", role: "Alumni", department: "Economics", batch: "2020", status: "Approved", submitDate: "Oct 28, 2023, 02:15 PM", certImg: "https://images.unsplash.com/photo-1589330694653-efa6477e0fa0?auto=format&fit=crop&q=80&w=800" },
  { id: 103, name: "Kamrul Hasan", email: "kamrul.h@alumni.northsouth.edu", avatar: "https://i.pravatar.cc/150?u=8", role: "Alumni", department: "Computer Science", batch: "2019", status: "Rejected", submitDate: "Nov 01, 2023, 09:00 AM", certImg: "https://images.unsplash.com/photo-1589330694653-efa6477e0fa0?auto=format&fit=crop&q=80&w=800" },
  { id: 104, name: "Farhana Rahman", email: "farhana.r@alumni.northsouth.edu", avatar: "https://i.pravatar.cc/150?u=9", role: "Alumni", department: "Pharmacy", batch: "2021", status: "Pending", submitDate: "Nov 06, 2023, 11:45 AM", certImg: "https://images.unsplash.com/photo-1589330694653-efa6477e0fa0?auto=format&fit=crop&q=80&w=800" },
];

const mockJobs = [
  { id: 201, title: "Senior Product Designer", company: "TechCorp Ltd.", posterName: "Nadia Islam", posterAvatar: "https://i.pravatar.cc/150?u=5", type: "Full-time", department: "Computer Science", status: "Pending", submitDate: "Nov 08, 2023", location: "Dhaka, Bangladesh", deadline: "Dec 01, 2023", link: "https://techcorp.com/careers", description: "We are looking for an experienced product designer to lead our core platform redesign. Must have a strong portfolio demonstrating end-to-end UX/UI capabilities." },
  { id: 202, title: "Software Engineering Intern", company: "InnoSoft", posterName: "Dr. Hasan Mahmud", posterAvatar: "https://i.pravatar.cc/150?u=3", type: "Internship", department: "Electrical Eng", status: "Approved", submitDate: "Nov 05, 2023", location: "Remote", deadline: "Nov 25, 2023", link: "https://innosoft.io/interns", description: "Join our summer internship program to learn full-stack development. Ideal for 3rd or 4th-year students with basic knowledge of React and Node.js." },
  { id: 203, title: "Marketing Manager", company: "Global Reach", posterName: "Rafiq Ahmed", posterAvatar: "https://i.pravatar.cc/150?u=2", type: "Full-time", department: "Business Admin", status: "Rejected", submitDate: "Oct 30, 2023", location: "Chittagong", deadline: "Nov 15, 2023", link: "https://globalreach.co", description: "Seeking a dynamic marketing manager to lead our regional campaigns. 3+ years experience required." },
];

const mockDonors = [
  { id: 301, name: "Tariq Rahman", avatar: "https://i.pravatar.cc/150?u=4", role: "Student", bloodGroup: "O+", location: "Bashundhara R/A, Dhaka", availability: "Available", lastDonation: "Aug 15, 2023", joinDate: "Mar 22, 2023" },
  { id: 302, name: "Ayesha Siddiqa", avatar: "https://i.pravatar.cc/150?u=7", role: "Student", bloodGroup: "B-", location: "Uttara, Dhaka", availability: "Unavailable", lastDonation: "Nov 01, 2023", joinDate: "Jan 05, 2024" },
  { id: 303, name: "Dr. Hasan Mahmud", avatar: "https://i.pravatar.cc/150?u=3", role: "Faculty", bloodGroup: "AB+", location: "Gulshan, Dhaka", availability: "Available", lastDonation: "Never", joinDate: "Jan 10, 2022" },
];

const mockBloodRequests = [
  { id: 401, hospital: "Apollo Hospital", bloodGroup: "O+", units: 2, location: "Bashundhara R/A, Dhaka", urgency: "Critical", posterName: "Sarah Khan", posterAvatar: "https://i.pravatar.cc/150?u=1", contact: "+880 1711-000000", timePosted: "2 hours ago", status: "Active", notes: "Patient is undergoing emergency surgery. Need blood within 4 hours. Please contact directly." },
  { id: 402, hospital: "Square Hospital", bloodGroup: "AB-", units: 1, location: "Panthapath, Dhaka", urgency: "Urgent", posterName: "Rafiq Ahmed", posterAvatar: "https://i.pravatar.cc/150?u=2", contact: "+880 1819-111111", timePosted: "5 hours ago", status: "Active", notes: "Needed by tomorrow morning for a planned operation." },
  { id: 403, hospital: "Dhaka Medical College", bloodGroup: "B+", units: 3, location: "Bakshibazar, Dhaka", urgency: "Normal", posterName: "Tariq Rahman", posterAvatar: "https://i.pravatar.cc/150?u=4", contact: "+880 1922-222222", timePosted: "1 day ago", status: "Resolved", notes: "Dengue patient requiring platelets." },
];

const mockAds = [
  { id: 501, title: "Spring Semester Orientation", img: "https://images.unsplash.com/photo-1523580494112-071d32833a0b?auto=format&fit=crop&q=80&w=1200&h=400", placement: "Home Banner", startDate: "Mar 10, 2026", endDate: "Mar 20, 2026", status: "Active", link: "https://nsunext.edu/orientation", notes: "Main banner for spring intake." },
  { id: 502, title: "Tech Career Fair 2026", img: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=1200&h=400", placement: "Jobs Section", startDate: "Apr 01, 2026", endDate: "Apr 05, 2026", status: "Scheduled", link: "https://nsunext.edu/career-fair", notes: "Sponsored by tech club." },
  { id: 503, title: "Alumni Donation Drive", img: "https://images.unsplash.com/photo-1531206715517-5c0ba140fea2?auto=format&fit=crop&q=80&w=1200&h=400", placement: "Home Banner", startDate: "Jan 01, 2026", endDate: "Jan 31, 2026", status: "Expired", link: "https://nsunext.edu/donate", notes: "Annual donation drive banner." },
];

const navItems = [
  { name: 'Dashboard', icon: LayoutDashboard },
  { name: 'Users', icon: Users },
  { name: 'Alumni Verification', icon: GraduationCap },
  { name: 'Jobs', icon: Briefcase },
  { name: 'Emergency Support', icon: AlertTriangle },
  { name: 'Ads', icon: Megaphone },
  { name: 'Reports', icon: BarChart3 },
  { name: 'Settings', icon: Settings },
];

// --- HELPER COMPONENTS ---
const Badge = ({ children, type }) => {
  const styles = {
    Student: "bg-blue-100 text-blue-800 dark:bg-blue-500/20 dark:text-blue-300",
    Alumni: "bg-purple-100 text-purple-800 dark:bg-purple-500/20 dark:text-purple-300",
    Faculty: "bg-amber-100 text-amber-800 dark:bg-amber-500/20 dark:text-amber-300",
    Admin: "bg-gray-100 text-gray-800 dark:bg-neutral-800/30 dark:text-neutral-300",
    default: "bg-gray-100 text-gray-800 dark:bg-neutral-800 dark:text-neutral-300"
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${styles[type] || styles.default}`}>
      {children}
    </span>
  );
};

const StatusIndicator = ({ status }) => {
  const config = {
    Active: { color: "text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/20", dot: "bg-emerald-500" },
    Approved: { color: "text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/20", dot: "bg-emerald-500" },
    Resolved: { color: "text-gray-700 dark:text-neutral-400 bg-gray-50 dark:bg-neutral-700/10 border-gray-200 dark:border-neutral-700/20", dot: "bg-neutral-400" },
    Suspended: { color: "text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20", dot: "bg-red-500" },
    Rejected: { color: "text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20", dot: "bg-red-500" },
    Pending: { color: "text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20", dot: "bg-amber-500" },
    Scheduled: { color: "text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-500/10 border-blue-200 dark:border-blue-500/20", dot: "bg-blue-500" },
    Expired: { color: "text-slate-600 dark:text-neutral-400 bg-slate-100 dark:bg-neutral-900 border-slate-300 dark:border-neutral-800", dot: "bg-neutral-500" },
    Draft: { color: "text-gray-600 dark:text-neutral-400 bg-gray-100 dark:bg-neutral-900 border-gray-300 dark:border-neutral-800", dot: "bg-neutral-400" },
  };
  const style = config[status] || config.Active;

  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium border ${style.color}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${style.dot} ${status === 'Pending' ? 'animate-pulse' : ''}`}></span>
      {status}
    </span>
  );
};

const UrgencyBadge = ({ urgency }) => {
  const config = {
    Critical: "bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-300 border border-red-200 dark:border-red-500/30",
    Urgent: "bg-amber-100 text-amber-800 dark:bg-amber-500/20 dark:text-amber-300 border border-amber-200 dark:border-amber-500/30",
    Normal: "bg-blue-50 text-blue-700 dark:bg-blue-500/10 dark:text-blue-300 border border-blue-200 dark:border-blue-500/30",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${config[urgency] || config.Normal}`}>
      {urgency === 'Critical' && <AlertTriangle size={10} className="mr-1" />}
      {urgency}
    </span>
  );
};

const MinimalBarChart = () => (
  <div className="relative flex items-end justify-between h-32 w-full mt-4 gap-2">
    <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-0 z-0">
      {[1,2,3,4].map(i => <div key={i} className="w-full border-t border-gray-100 dark:border-neutral-800/50"></div>)}
    </div>
    {[40, 70, 45, 90, 65, 85, 100].map((height, i) => (
      <div key={i} className="w-1/7 bg-blue-100 dark:bg-blue-900/40 rounded-t-md hover:bg-blue-200 dark:hover:bg-blue-800/60 transition-colors relative group flex-1 z-10" style={{ height: `${height}%` }}>
        <div className="absolute bottom-0 w-full bg-blue-600 dark:bg-blue-500 rounded-t-md opacity-80" style={{ height: `${height * 0.7}%` }}></div>
      </div>
    ))}
  </div>
);

const MinimalLineChart = () => (
  <div className="w-full h-32 mt-4 relative">
    <svg viewBox="0 0 100 40" className="w-full h-full overflow-visible" preserveAspectRatio="none">
      <defs>
        <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0" />
        </linearGradient>
      </defs>
      <line x1="0" y1="10" x2="100" y2="10" stroke="currentColor" strokeWidth="0.5" className="text-gray-100 dark:text-neutral-800/50" />
      <line x1="0" y1="20" x2="100" y2="20" stroke="currentColor" strokeWidth="0.5" className="text-gray-100 dark:text-neutral-800/50" />
      <line x1="0" y1="30" x2="100" y2="30" stroke="currentColor" strokeWidth="0.5" className="text-gray-100 dark:text-neutral-800/50" />
      <path d="M0,40 L0,30 C10,30 15,10 25,15 C35,20 40,5 50,10 C60,15 65,25 75,20 C85,15 90,5 100,5 L100,40 Z" fill="url(#lineGrad)" />
      <path d="M0,30 C10,30 15,10 25,15 C35,20 40,5 50,10 C60,15 65,25 75,20 C85,15 90,5 100,5" fill="none" stroke="#8b5cf6" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="25" cy="15" r="1.5" fill="#8b5cf6" className="animate-pulse" />
      <circle cx="50" cy="10" r="1.5" fill="#8b5cf6" className="animate-pulse" />
      <circle cx="75" cy="20" r="1.5" fill="#8b5cf6" className="animate-pulse" />
      <circle cx="100" cy="5" r="1.5" fill="#8b5cf6" className="animate-pulse" />
    </svg>
  </div>
);

// --- INDEPENDENT VIEW COMPONENTS ---

const DashboardView = ({ setActiveTab }) => (
  <div className="max-w-7xl mx-auto space-y-5 animate-in fade-in duration-300 pb-8">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Dashboard Overview</h1>
        <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">Welcome back, Fahim. Here's what's happening today.</p>
      </div>
      <span className="text-sm text-gray-500 dark:text-neutral-400 hidden sm:block">Last updated: Just now</span>
    </div>

    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
      {kpis.map((kpi, index) => (
        <div key={index} className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-5 flex flex-col transition-all duration-200 hover:-translate-y-0.5">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-gray-500 dark:text-neutral-400 truncate">{kpi.title}</p>
            <div className={`p-2 rounded-lg ${kpi.alert ? 'bg-red-50 text-red-600 dark:bg-red-500/10 dark:text-red-400' : 'bg-gray-50 text-gray-400 dark:bg-neutral-800/50 dark:text-neutral-400'}`}>
              <kpi.icon size={18} />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{kpi.value}</h3>
            <div className="mt-1 flex items-center text-xs">
              {kpi.positive ? <TrendingUp size={14} className="text-emerald-500 mr-1" /> : <TrendingDown size={14} className={`${kpi.alert ? 'text-red-500' : 'text-amber-500'} mr-1`} />}
              <span className={`${kpi.positive ? 'text-emerald-600 dark:text-emerald-400' : kpi.alert ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}>{kpi.trend}</span>
            </div>
          </div>
        </div>
      ))}
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2 space-y-5">
        <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 overflow-hidden flex flex-col transition-colors duration-200">
          <div className="px-5 py-4 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Pending Actions</h2>
            <button onClick={() => setActiveTab('Alumni Verification')} className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">View all</button>
          </div>
          <div className="p-0 sm:p-2 flex-1">
            <ul className="divide-y divide-gray-100 dark:divide-neutral-800/50 sm:divide-transparent space-y-0 sm:space-y-2">
              {pendingActions.map((action) => (
                <li key={action.id} className="p-4 sm:rounded-lg sm:border sm:border-gray-100 dark:sm:border-neutral-800/50 hover:bg-gray-50 dark:hover:bg-neutral-800/30 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium w-max ${action.badgeColor}`}>{action.type}</span>
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-neutral-100">{action.title}</p>
                      <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-neutral-400 space-x-2">
                        <span>{action.subtitle}</span>
                        <span className="hidden sm:inline">•</span>
                        <span className="flex items-center"><Clock size={12} className="mr-1"/> {action.time}</span>
                      </div>
                    </div>
                  </div>
                  <button className="w-full sm:w-auto px-4 py-2 text-sm font-medium rounded-lg text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-500/10 hover:bg-blue-100 dark:hover:bg-blue-500/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-neutral-900 transition-colors">
                    Review
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-5 transition-colors duration-200">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-700 dark:text-neutral-300">New Users This Week</h3>
              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-1 rounded-full">+18.2%</span>
            </div>
            <div className="flex items-baseline space-x-2">
              <h4 className="text-2xl font-bold text-gray-900 dark:text-white">452</h4>
              <span className="text-sm text-gray-500 dark:text-neutral-400">vs 382 last week</span>
            </div>
            <MinimalBarChart />
          </div>
          
          <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-5 transition-colors duration-200">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-700 dark:text-neutral-300">Jobs Posted This Week</h3>
              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-1 rounded-full">+4.1%</span>
            </div>
            <div className="flex items-baseline space-x-2">
              <h4 className="text-2xl font-bold text-gray-900 dark:text-white">128</h4>
              <span className="text-sm text-gray-500 dark:text-neutral-400">vs 123 last week</span>
            </div>
            <MinimalLineChart />
          </div>
        </div>
      </div>

      <div className="lg:col-span-1">
        <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 h-full flex flex-col transition-colors duration-200">
          <div className="px-5 py-4 border-b border-gray-200 dark:border-neutral-800">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Activity</h2>
          </div>
          <div className="p-5 flex-1">
            <div className="flow-root">
              <ul className="-mb-8">
                {recentActivity.map((activity, activityIdx) => (
                  <li key={activity.id}>
                    <div className="relative pb-8">
                      {activityIdx !== recentActivity.length - 1 ? (
                        <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200 dark:bg-neutral-800" aria-hidden="true" />
                      ) : null}
                      <div className="relative flex space-x-3">
                        <div>
                          <span className={`h-8 w-8 rounded-full flex items-center justify-center ring-8 ring-white dark:ring-neutral-900 transition-shadow duration-200 ${activity.color}`}>
                            <activity.icon size={16} />
                          </span>
                        </div>
                        <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                          <div><p className="text-sm text-gray-600 dark:text-neutral-300">{activity.text}</p></div>
                          <div className="text-right text-xs whitespace-nowrap text-gray-500 dark:text-neutral-400">
                            <time>{activity.time}</time>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <button className="mt-8 w-full block text-center px-4 py-2 border border-gray-200 dark:border-neutral-700 text-sm font-medium rounded-lg text-gray-700 dark:text-neutral-300 bg-gray-50 dark:bg-neutral-900 hover:bg-gray-100 dark:hover:bg-neutral-800/80 transition-colors">
              View full activity log
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const UsersView = ({ setSelectedUser }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [verificationFilter, setVerificationFilter] = useState("All");

  const filteredUsers = useMemo(() => {
    return mockUsers.filter(user => {
      const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            user.department.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRole = roleFilter === "All" || user.role === roleFilter;
      const matchesStatus = statusFilter === "All" || user.status === statusFilter;
      const matchesVerification = verificationFilter === "All" || user.verification === verificationFilter;
      return matchesSearch && matchesRole && matchesStatus && matchesVerification;
    });
  }, [searchQuery, roleFilter, statusFilter, verificationFilter]);

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">User Management</h1>
          <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">Manage student, alumni, faculty, and admin accounts</p>
        </div>
        <button className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg text-sm font-medium text-gray-700 dark:text-neutral-200 bg-white dark:bg-neutral-900 hover:bg-gray-50 dark:hover:bg-neutral-800 transition-colors">
          <Download size={16} className="mr-2" /> Export CSV
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Users", value: mockUsers.length, color: "text-blue-600 dark:text-blue-400" },
          { label: "Active Users", value: mockUsers.filter(u => u.status === 'Active').length, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "Suspended", value: mockUsers.filter(u => u.status === 'Suspended').length, color: "text-red-600 dark:text-red-400" },
          { label: "Pending Verification", value: mockUsers.filter(u => u.status === 'Pending').length, color: "text-yellow-600 dark:text-yellow-400" }
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-4 flex flex-col justify-center">
            <span className="text-xs font-medium text-gray-500 dark:text-neutral-400 uppercase tracking-wider">{stat.label}</span>
            <span className={`text-2xl font-bold mt-1 ${stat.color}`}>{stat.value}</span>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-neutral-800 bg-gray-50/50 dark:bg-neutral-900/50 flex flex-col lg:flex-row gap-4 items-center">
          <div className="relative w-full lg:flex-1">
             <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Search className="h-4 w-4 text-gray-400 dark:text-neutral-500" /></div>
             <input type="text" placeholder="Search by name, email, or department" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg leading-5 bg-white dark:bg-neutral-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors" />
          </div>
          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Filter className="h-3.5 w-3.5 text-gray-400 dark:text-neutral-500" /></div>
              <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="block w-full sm:w-36 pl-9 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Roles</option><option value="Student">Student</option><option value="Alumni">Alumni</option><option value="Faculty">Faculty</option><option value="Admin">Admin</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
            <div className="relative flex-1 sm:flex-none">
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="block w-full sm:w-36 pl-3 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Status</option><option value="Active">Active</option><option value="Suspended">Suspended</option><option value="Pending">Pending</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
            <div className="relative flex-1 sm:flex-none">
              <select value={verificationFilter} onChange={(e) => setVerificationFilter(e.target.value)} className="block w-full sm:w-40 pl-3 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">Any Verification</option><option value="Verified">Verified</option><option value="Unverified">Unverified</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="hidden md:block overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-neutral-800">
            <thead className="bg-gray-50 dark:bg-neutral-900/80">
              <tr>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Profile</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Role</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Department & Email</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Joined Date</th>
                <th scope="col" className="relative px-6 py-3.5 text-right text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-neutral-900 divide-y divide-gray-100 dark:divide-neutral-800/50">
              {filteredUsers.length === 0 ? (
                <tr><td colSpan="6" className="px-6 py-12 text-center text-gray-500 dark:text-neutral-400">No users found.</td></tr>
              ) : filteredUsers.map((user) => (
                <tr key={user.id} className={`group transition-colors ${user.status === 'Suspended' ? 'bg-red-50/30 hover:bg-red-50/60 dark:bg-red-900/10 dark:hover:bg-red-900/20' : 'hover:bg-gray-50 dark:hover:bg-neutral-800/30'}`}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <img className="h-10 w-10 rounded-full border border-gray-200 dark:border-neutral-700 object-cover" src={user.avatar} alt="" />
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-white flex items-center">
                          {user.name} {user.verification === 'Verified' && <CheckCircle2 size={14} className="ml-1 text-blue-500" title="Verified" />}
                        </div>
                        {user.batch && <div className="text-xs text-gray-500 dark:text-neutral-400 mt-0.5">Batch {user.batch}</div>}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap"><Badge type={user.role}>{user.role}</Badge></td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-neutral-200">{user.department}</div>
                    <div className="text-sm text-gray-500 dark:text-neutral-400 mt-0.5">{user.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap"><StatusIndicator status={user.status} /></td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-neutral-400">{user.joinDate}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end">
                      <button onClick={() => setSelectedUser(user)} className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors dark:bg-blue-500/10 dark:text-blue-400 dark:hover:bg-blue-500/20">Manage</button>
                      <div className="w-px h-6 bg-gray-200 dark:bg-neutral-800 mx-3 hidden group-hover:block transition-all"></div>
                      <div className="hidden group-hover:flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                        {user.status === 'Suspended' ? (
                          <button className="p-1.5 text-emerald-600 hover:text-emerald-700 dark:text-emerald-500 dark:hover:text-emerald-400 rounded-md hover:bg-emerald-50 dark:hover:bg-emerald-500/10 transition-colors" title="Quick Reactivate"><CheckCircle size={18} /></button>
                        ) : (
                          <button className="p-1.5 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 rounded-md hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors" title="Quick Suspend"><Ban size={18} /></button>
                        )}
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="md:hidden divide-y divide-gray-200 dark:divide-neutral-800">
          {filteredUsers.map((user) => (
            <div key={user.id} className={`p-5 transition-colors ${user.status === 'Suspended' ? 'bg-red-50/30 dark:bg-red-900/10' : 'hover:bg-gray-50 dark:hover:bg-neutral-800/30'}`}>
              <div className="flex items-center space-x-3 mb-4">
                <img className="h-12 w-12 rounded-full border-2 border-white dark:border-neutral-900 object-cover" src={user.avatar} alt="" />
                <div>
                  <p className="text-base font-medium text-gray-900 dark:text-white flex items-center">{user.name}{user.verification === 'Verified' && <CheckCircle2 size={14} className="ml-1.5 text-blue-500" />}</p>
                  <p className="text-sm text-gray-500 dark:text-neutral-400 mt-0.5">{user.email}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mb-5">
                <StatusIndicator status={user.status} />
                <Badge type={user.role}>{user.role}</Badge>
                <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-600 dark:bg-neutral-800 dark:text-neutral-300">{user.department}</span>
              </div>
              <div className="border-t border-gray-100 dark:border-neutral-800/50 pt-4">
                <button onClick={() => setSelectedUser(user)} className="w-full inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors dark:bg-blue-500/10 dark:text-blue-400 dark:hover:bg-blue-500/20">Manage Profile</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const AlumniVerificationView = ({ setSelectedVerification }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [deptFilter, setDeptFilter] = useState("All");

  const filteredVerifications = useMemo(() => {
    return mockVerifications.filter(v => {
      const matchesSearch = v.name.toLowerCase().includes(searchQuery.toLowerCase()) || v.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "All" || v.status === statusFilter;
      const matchesDept = deptFilter === "All" || v.department === deptFilter;
      return matchesSearch && matchesStatus && matchesDept;
    });
  }, [searchQuery, statusFilter, deptFilter]);

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Alumni Verification</h1>
          <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">Review and approve alumni certificate submissions</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Pending", value: mockVerifications.filter(v => v.status === 'Pending').length, color: "text-amber-600 dark:text-amber-400" },
          { label: "Verified Alumni", value: mockVerifications.filter(v => v.status === 'Approved').length, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "Rejected Requests", value: mockVerifications.filter(v => v.status === 'Rejected').length, color: "text-red-600 dark:text-red-400" },
          { label: "Total Alumni", value: mockVerifications.length, color: "text-blue-600 dark:text-blue-400" }
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-4 flex flex-col justify-center">
            <span className="text-xs font-medium text-gray-500 dark:text-neutral-400 uppercase tracking-wider">{stat.label}</span>
            <span className={`text-2xl font-bold mt-1 ${stat.color}`}>{stat.value}</span>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-neutral-800 bg-gray-50/50 dark:bg-neutral-900/50 flex flex-col lg:flex-row gap-4 items-center">
          <div className="relative w-full lg:flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Search className="h-4 w-4 text-gray-400 dark:text-neutral-500" /></div>
            <input type="text" placeholder="Search by name or email" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg leading-5 bg-white dark:bg-neutral-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
          </div>
          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Filter className="h-3.5 w-3.5 text-gray-400 dark:text-neutral-500" /></div>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="block w-full sm:w-40 pl-9 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Status</option><option value="Pending">Pending</option><option value="Approved">Approved</option><option value="Rejected">Rejected</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
            <div className="relative flex-1 sm:flex-none">
              <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="block w-full sm:w-48 pl-3 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Departments</option><option value="Computer Science">Computer Science</option><option value="Business Admin">Business Admin</option><option value="Economics">Economics</option><option value="Pharmacy">Pharmacy</option><option value="Electrical Eng">Electrical Eng</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="hidden lg:block overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-neutral-800">
            <thead className="bg-gray-50 dark:bg-neutral-900/80">
              <tr>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Profile</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Dept & Batch</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Certificate</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Submitted</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Status</th>
                <th scope="col" className="relative px-6 py-3.5 text-right text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-neutral-900 divide-y divide-gray-100 dark:divide-neutral-800/50">
              {filteredVerifications.length === 0 ? (
                <tr><td colSpan="6" className="px-6 py-12 text-center text-gray-500 dark:text-neutral-400">No requests found.</td></tr>
              ) : filteredVerifications.map((req) => (
                <tr key={req.id} className={`group transition-colors ${req.status === 'Pending' ? 'bg-amber-50/20 hover:bg-amber-50/40 dark:bg-amber-900/5 dark:hover:bg-amber-900/10' : 'hover:bg-gray-50 dark:hover:bg-neutral-800/30'}`}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <img className="h-10 w-10 rounded-full border border-gray-200 dark:border-neutral-700 object-cover" src={req.avatar} alt="" />
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-white flex items-center">{req.name}</div>
                        <div className="mt-1"><Badge type="Alumni">Alumni</Badge></div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-neutral-200">{req.department}</div>
                    <div className="text-sm text-gray-500 dark:text-neutral-400 mt-0.5">Batch {req.batch}</div>
                    <div className="text-xs text-gray-400 dark:text-neutral-500 mt-0.5">{req.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button onClick={() => setSelectedVerification(req)} className="group inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 transition-colors">
                      <FileText size={16} className="mr-2 text-gray-400 group-hover:text-blue-600 dark:text-neutral-500 dark:group-hover:text-blue-400 transition-colors" />
                      <span className="underline decoration-blue-200 dark:decoration-blue-800 underline-offset-4 group-hover:decoration-blue-600 dark:group-hover:decoration-blue-400 transition-colors">View Certificate</span>
                    </button>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-neutral-400">{req.submitDate}</td>
                  <td className="px-6 py-4 whitespace-nowrap"><StatusIndicator status={req.status} /></td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {req.status === 'Pending' ? (
                      <div className="flex items-center justify-end space-x-2">
                        <button className="inline-flex items-center px-2.5 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md border border-emerald-200 transition-colors dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20 dark:hover:bg-emerald-500/20" title="Approve"><Check size={14} className="mr-1" /> Approve</button>
                        <button className="inline-flex items-center px-2.5 py-1.5 text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-md border border-red-200 transition-colors dark:bg-red-500/10 dark:text-red-400 dark:border-red-500/20 dark:hover:bg-red-500/20" title="Reject"><X size={14} className="mr-1" /> Reject</button>
                      </div>
                    ) : (<span className="text-xs text-gray-400 dark:text-neutral-500 italic">Moderated</span>)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="lg:hidden divide-y divide-gray-200 dark:divide-neutral-800">
          {filteredVerifications.map((req) => (
            <div key={req.id} className={`p-5 transition-colors ${req.status === 'Pending' ? 'bg-amber-50/20 dark:bg-amber-900/5' : 'hover:bg-gray-50 dark:hover:bg-neutral-800/30'}`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <img className="h-12 w-12 rounded-full border-2 border-white dark:border-neutral-900 object-cover" src={req.avatar} alt="" />
                  <div>
                    <p className="text-base font-medium text-gray-900 dark:text-white flex items-center">{req.name}</p>
                    <p className="text-sm text-gray-500 dark:text-neutral-400 mt-0.5">{req.department} • Batch {req.batch}</p>
                  </div>
                </div>
                <StatusIndicator status={req.status} />
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-5 pt-4 border-t border-gray-100 dark:border-neutral-800/50 gap-3">
                <button onClick={() => setSelectedVerification(req)} className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors dark:bg-blue-500/10 dark:text-blue-400 dark:hover:bg-blue-500/20"><FileText size={16} className="mr-2" /> Review Document</button>
                {req.status === 'Pending' && (
                  <div className="flex space-x-2">
                    <button className="flex-1 sm:flex-none inline-flex justify-center items-center px-3 py-2 text-sm font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 dark:text-emerald-400 dark:bg-emerald-500/10 dark:border-emerald-500/20 dark:hover:bg-emerald-500/20 rounded-lg transition-colors"><Check size={16} className="mr-1.5" /> Approve</button>
                    <button className="flex-1 sm:flex-none inline-flex justify-center items-center px-3 py-2 text-sm font-medium text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 dark:text-red-400 dark:bg-red-500/10 dark:border-red-500/20 dark:hover:bg-red-500/20 rounded-lg transition-colors"><X size={16} className="mr-1.5" /> Reject</button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const JobsView = ({ setSelectedJob }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [typeFilter, setTypeFilter] = useState("All");
  const [deptFilter, setDeptFilter] = useState("All");

  const filteredJobs = useMemo(() => {
    return mockJobs.filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            job.posterName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "All" || job.status === statusFilter;
      const matchesType = typeFilter === "All" || job.type === typeFilter;
      const matchesDept = deptFilter === "All" || job.department === deptFilter;
      return matchesSearch && matchesStatus && matchesType && matchesDept;
    });
  }, [searchQuery, statusFilter, typeFilter, deptFilter]);

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Job Management</h1>
          <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">Review and moderate job postings submitted by alumni and faculty</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Jobs Posted", value: mockJobs.length, color: "text-blue-600 dark:text-blue-400" },
          { label: "Pending Approval", value: mockJobs.filter(j => j.status === 'Pending').length, color: "text-amber-600 dark:text-amber-400" },
          { label: "Approved Jobs", value: mockJobs.filter(j => j.status === 'Approved').length, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "Rejected Jobs", value: mockJobs.filter(j => j.status === 'Rejected').length, color: "text-red-600 dark:text-red-400" }
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-4 flex flex-col justify-center">
            <span className="text-xs font-medium text-gray-500 dark:text-neutral-400 uppercase tracking-wider">{stat.label}</span>
            <span className={`text-2xl font-bold mt-1 ${stat.color}`}>{stat.value}</span>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-neutral-800 bg-gray-50/50 dark:bg-neutral-900/50 flex flex-col lg:flex-row gap-4 items-center">
          <div className="relative w-full lg:flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Search className="h-4 w-4 text-gray-400 dark:text-neutral-500" /></div>
            <input type="text" placeholder="Search by job title, company, or poster name" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg leading-5 bg-white dark:bg-neutral-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Filter className="h-3.5 w-3.5 text-gray-400 dark:text-neutral-500" /></div>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="block w-full sm:w-36 pl-9 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Status</option><option value="Pending">Pending</option><option value="Approved">Approved</option><option value="Rejected">Rejected</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
            <div className="relative flex-1 sm:flex-none">
              <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="block w-full sm:w-36 pl-3 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Types</option><option value="Full-time">Full-time</option><option value="Internship">Internship</option><option value="Remote">Remote</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
            <div className="relative flex-1 sm:flex-none">
              <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="block w-full sm:w-48 pl-3 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Departments</option><option value="Computer Science">Computer Science</option><option value="Business Admin">Business Admin</option><option value="Electrical Eng">Electrical Eng</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="hidden lg:block overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-neutral-800">
            <thead className="bg-gray-50 dark:bg-neutral-900/80">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Job Details</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Posted By</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Category</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Submitted</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                <th scope="col" className="relative px-4 py-3 text-right text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-neutral-900 divide-y divide-gray-100 dark:divide-neutral-800/50">
              {filteredJobs.length === 0 ? (
                <tr><td colSpan="6" className="px-4 py-12 text-center text-gray-500 dark:text-neutral-400">No jobs found matching criteria.</td></tr>
              ) : filteredJobs.map((job) => (
                <tr key={job.id} className={`group transition-colors ${job.status === 'Pending' ? 'bg-amber-50/20 hover:bg-amber-50/40 dark:bg-amber-900/5 dark:hover:bg-amber-900/10' : 'hover:bg-gray-50 dark:hover:bg-neutral-800/30'}`}>
                  <td className="px-4 py-3 max-w-[250px] lg:max-w-xs">
                    <div className="text-sm font-bold text-gray-900 dark:text-white truncate" title={job.title}>{job.title}</div>
                    <div className="text-sm flex items-center text-gray-500 dark:text-neutral-400 mt-1 flex-wrap gap-2">
                      <span className="flex items-center whitespace-nowrap"><Briefcase size={12} className="mr-1" /> {job.company}</span>
                      <span className="flex items-center text-gray-400 dark:text-neutral-500 whitespace-nowrap"><MapPin size={12} className="mr-1" /> {job.location}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center">
                      <img className="h-8 w-8 rounded-full border border-gray-200 dark:border-neutral-700 object-cover" src={job.posterAvatar} alt="" />
                      <span className="ml-3 text-sm font-medium text-gray-700 dark:text-neutral-300">{job.posterName}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap space-y-1">
                    <div className="block"><Badge type={job.type === 'Internship' ? 'Student' : (job.type === 'Remote' ? 'Faculty' : 'Alumni')}>{job.type}</Badge></div>
                    <div className="block"><span className="inline-flex text-xs text-gray-500 dark:text-neutral-400">{job.department}</span></div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-neutral-400">{job.submitDate}</td>
                  <td className="px-4 py-3 whitespace-nowrap"><StatusIndicator status={job.status} /></td>
                  <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                    {job.status === 'Pending' ? (
                      <div className="flex items-center justify-end space-x-2">
                        <button onClick={() => setSelectedJob(job)} className="group inline-flex items-center text-xs font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 transition-colors">
                          <Eye size={14} className="mr-1.5 text-gray-400 group-hover:text-blue-600 dark:text-neutral-500 dark:group-hover:text-blue-400" />
                          <span className="underline decoration-blue-200 dark:decoration-blue-800 underline-offset-4 group-hover:decoration-blue-600 dark:group-hover:decoration-blue-400">Preview</span>
                        </button>
                        <div className="flex space-x-1.5 border-l border-gray-200 dark:border-neutral-800 pl-2">
                          <button className="inline-flex items-center px-2 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded border border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20 dark:hover:bg-emerald-500/20" title="Approve"><Check size={14} className="mr-1" /> Approve</button>
                          <button className="inline-flex items-center px-2 py-1.5 text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded border border-red-200 dark:bg-red-500/10 dark:text-red-400 dark:border-red-500/20 dark:hover:bg-red-500/20" title="Reject"><X size={14} className="mr-1" /> Reject</button>
                        </div>
                      </div>
                    ) : (
                      <button onClick={() => setSelectedJob(job)} className="group inline-flex items-center text-xs font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 transition-colors">
                        <Eye size={14} className="mr-1.5 text-gray-400 group-hover:text-blue-600 dark:text-neutral-500 dark:group-hover:text-blue-400" />
                        <span className="underline decoration-blue-200 dark:decoration-blue-800 underline-offset-4 group-hover:decoration-blue-600 dark:group-hover:decoration-blue-400">View Details</span>
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="lg:hidden divide-y divide-gray-200 dark:divide-neutral-800">
          {filteredJobs.map((job) => (
            <div key={job.id} className={`p-5 transition-colors ${job.status === 'Pending' ? 'bg-amber-50/20 dark:bg-amber-900/5' : 'hover:bg-gray-50 dark:hover:bg-neutral-800/30'}`}>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white">{job.title}</h3>
                  <div className="text-sm flex items-center text-gray-500 dark:text-neutral-400 mt-1 flex-wrap gap-y-1 gap-x-3">
                    <span className="flex items-center"><Briefcase size={12} className="mr-1.5" /> {job.company}</span>
                    <span className="flex items-center text-gray-400 dark:text-neutral-500"><MapPin size={12} className="mr-1.5" /> {job.location}</span>
                  </div>
                </div>
                <StatusIndicator status={job.status} />
              </div>
              <div className="flex flex-wrap gap-2 mt-4 mb-5">
                <Badge type={job.type === 'Internship' ? 'Student' : (job.type === 'Remote' ? 'Faculty' : 'Alumni')}>{job.type}</Badge>
                <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-600 dark:bg-neutral-800 dark:text-neutral-300">{job.department}</span>
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-t border-gray-100 dark:border-neutral-800/50 pt-4 gap-3">
                <button onClick={() => setSelectedJob(job)} className="inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg dark:bg-blue-500/10 dark:text-blue-400 dark:hover:bg-blue-500/20">
                  <Eye size={16} className="mr-2" /> Preview Post
                </button>
                {job.status === 'Pending' && (
                  <div className="flex space-x-2">
                    <button className="flex-1 sm:flex-none inline-flex justify-center items-center px-3 py-2 text-sm font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 dark:text-emerald-400 dark:bg-emerald-500/10 dark:border-emerald-500/20 dark:hover:bg-emerald-500/20 rounded-lg"><Check size={16} className="mr-1.5" /> Approve</button>
                    <button className="flex-1 sm:flex-none inline-flex justify-center items-center px-3 py-2 text-sm font-medium text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 dark:text-red-400 dark:bg-red-500/10 dark:border-red-500/20 dark:hover:bg-red-500/20 rounded-lg"><X size={16} className="mr-1.5" /> Reject</button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const EmergencySupportView = ({ setSelectedDonor, setSelectedBloodRequest }) => {
  const [subTab, setSubTab] = useState('Donors');
  const [searchQuery, setSearchQuery] = useState("");
  const [bloodGroupFilter, setBloodGroupFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All"); 
  const [urgencyFilter, setUrgencyFilter] = useState("All");

  const filteredDonors = useMemo(() => {
    return mockDonors.filter(d => {
      const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) || d.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesBg = bloodGroupFilter === "All" || d.bloodGroup === bloodGroupFilter;
      const matchesStatus = statusFilter === "All" || d.availability === statusFilter;
      return matchesSearch && matchesBg && matchesStatus;
    });
  }, [searchQuery, bloodGroupFilter, statusFilter]);

  const filteredRequests = useMemo(() => {
    return mockBloodRequests.filter(r => {
      const matchesSearch = r.hospital.toLowerCase().includes(searchQuery.toLowerCase()) || r.posterName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesBg = bloodGroupFilter === "All" || r.bloodGroup === bloodGroupFilter;
      const matchesStatus = statusFilter === "All" || r.status === statusFilter;
      const matchesUrgency = urgencyFilter === "All" || r.urgency === urgencyFilter;
      return matchesSearch && matchesBg && matchesStatus && matchesUrgency;
    });
  }, [searchQuery, bloodGroupFilter, statusFilter, urgencyFilter]);

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Emergency Support</h1>
          <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">Monitor blood donors and moderate emergency blood requests</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Active Donors", value: mockDonors.length, color: "text-blue-600 dark:text-blue-400" },
          { label: "Available Donors", value: mockDonors.filter(d => d.availability === 'Available').length, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "Active Blood Requests", value: mockBloodRequests.filter(r => r.status === 'Active').length, color: "text-red-600 dark:text-red-400" },
          { label: "Requests Created Today", value: "2", color: "text-amber-600 dark:text-amber-400" }
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-4 flex flex-col justify-center">
            <span className="text-xs font-medium text-gray-500 dark:text-neutral-400 uppercase tracking-wider">{stat.label}</span>
            <span className={`text-2xl font-bold mt-1 ${stat.color}`}>{stat.value}</span>
          </div>
        ))}
      </div>

      <div className="flex justify-center sm:justify-start">
        <div className="inline-flex bg-gray-100 dark:bg-neutral-900/80 p-1 rounded-lg border border-gray-200 dark:border-neutral-800">
          <button onClick={() => { setSubTab('Donors'); setStatusFilter('All'); }} className={`flex items-center px-5 py-2 text-sm font-medium rounded-md transition-all ${subTab === 'Donors' ? 'bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-neutral-400 hover:text-gray-900 dark:hover:text-neutral-200'}`}>
            <Droplet size={16} className="mr-2" /> Donors
          </button>
          <button onClick={() => { setSubTab('Requests'); setStatusFilter('All'); }} className={`flex items-center px-5 py-2 text-sm font-medium rounded-md transition-all ${subTab === 'Requests' ? 'bg-white dark:bg-neutral-800 text-red-600 dark:text-red-400' : 'text-gray-500 dark:text-neutral-400 hover:text-gray-900 dark:hover:text-neutral-200'}`}>
            <HeartPulse size={16} className="mr-2" /> Blood Requests
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-800 rounded-xl overflow-hidden transition-all duration-300">
        <div className="p-4 border-b border-gray-200 dark:border-neutral-800 bg-gray-50/50 dark:bg-neutral-900/50 flex flex-col lg:flex-row gap-4 items-center">
          <div className="relative w-full lg:flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Search className="h-4 w-4 text-gray-400 dark:text-neutral-500" /></div>
            <input type="text" placeholder={subTab === 'Donors' ? "Search by name or location..." : "Search by hospital or user name..."} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg leading-5 bg-white dark:bg-neutral-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Droplet className="h-3.5 w-3.5 text-red-400" /></div>
              <select value={bloodGroupFilter} onChange={(e) => setBloodGroupFilter(e.target.value)} className="block w-full sm:w-36 pl-9 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Groups</option><option value="A+">A+</option><option value="A-">A-</option><option value="B+">B+</option><option value="B-">B-</option><option value="O+">O+</option><option value="O-">O-</option><option value="AB+">AB+</option><option value="AB-">AB-</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>

            {subTab === 'Requests' && (
              <div className="relative flex-1 sm:flex-none">
                <select value={urgencyFilter} onChange={(e) => setUrgencyFilter(e.target.value)} className="block w-full sm:w-36 pl-3 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                  <option value="All">All Urgency</option><option value="Critical">Critical</option><option value="Urgent">Urgent</option><option value="Normal">Normal</option>
                </select>
                <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
              </div>
            )}

            <div className="relative flex-1 sm:flex-none">
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="block w-full sm:w-36 pl-3 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                {subTab === 'Donors' ? (<><option value="All">All Availability</option><option value="Available">Available</option><option value="Unavailable">Unavailable</option></>) : (<><option value="All">All Status</option><option value="Active">Active</option><option value="Resolved">Resolved</option></>)}
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {subTab === 'Donors' ? (
          <>
            <div className="hidden lg:block overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-neutral-800">
                <thead className="bg-gray-50 dark:bg-neutral-900/80">
                  <tr>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Profile</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Blood Group</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Location</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Availability</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Last Donation</th>
                    <th scope="col" className="relative px-6 py-3.5 text-right text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-neutral-900 divide-y divide-gray-100 dark:divide-neutral-800/50">
                  {filteredDonors.length === 0 ? (
                    <tr><td colSpan="6" className="px-6 py-12 text-center text-gray-500 dark:text-neutral-400">No donors found.</td></tr>
                  ) : filteredDonors.map((donor) => (
                    <tr key={donor.id} className="hover:bg-gray-50 dark:hover:bg-neutral-800/30 transition-colors group">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <img className="h-10 w-10 rounded-full border border-gray-200 dark:border-neutral-700 object-cover" src={donor.avatar} alt="" />
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900 dark:text-white">{donor.name}</div>
                            <div className="mt-1"><Badge type={donor.role}>{donor.role}</Badge></div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-red-100 text-red-700 font-bold text-sm dark:bg-red-500/20 dark:text-red-400 border border-red-200 dark:border-red-500/30">{donor.bloodGroup}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900 dark:text-neutral-200 flex items-center"><MapPin size={14} className="mr-1.5 text-gray-400" /> {donor.location}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {donor.availability === 'Available' ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-800 dark:bg-emerald-500/20 dark:text-emerald-300">Available</span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800 dark:bg-neutral-800 dark:text-neutral-300">Unavailable</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-neutral-400">{donor.lastDonation}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end space-x-2">
                          <button onClick={() => setSelectedDonor(donor)} className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 transition-colors px-2 py-1">View</button>
                          <div className="w-px h-4 bg-gray-200 dark:bg-neutral-800 hidden group-hover:block transition-all"></div>
                          <button className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 hidden group-hover:block transition-all px-2 py-1" title="Remove Entry">Remove</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="lg:hidden divide-y divide-gray-200 dark:divide-neutral-800">
              {filteredDonors.map((donor) => (
                <div key={donor.id} className="p-5 hover:bg-gray-50 dark:hover:bg-neutral-800/30 transition-colors">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-3">
                      <img className="h-12 w-12 rounded-full border border-gray-200 dark:border-neutral-700 object-cover" src={donor.avatar} alt="" />
                      <div>
                        <p className="text-sm font-bold text-gray-900 dark:text-white">{donor.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge type={donor.role}>{donor.role}</Badge>
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded bg-red-100 text-red-700 font-bold text-xs dark:bg-red-500/20 dark:text-red-400 border border-red-200 dark:border-red-500/30">{donor.bloodGroup}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1.5 mb-4">
                    <p className="text-sm text-gray-600 dark:text-neutral-400 flex items-center"><MapPin size={14} className="mr-2 text-gray-400" /> {donor.location}</p>
                    <p className="text-sm text-gray-600 dark:text-neutral-400 flex items-center"><Clock size={14} className="mr-2 text-gray-400" /> Last Donation: {donor.lastDonation}</p>
                  </div>
                  <div className="flex items-center justify-between border-t border-gray-100 dark:border-neutral-800/50 pt-4">
                    {donor.availability === 'Available' ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-800 dark:bg-emerald-500/20 dark:text-emerald-300">Available</span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800 dark:bg-neutral-800 dark:text-neutral-300">Unavailable</span>
                    )}
                    <button onClick={() => setSelectedDonor(donor)} className="text-sm font-medium text-blue-600 dark:text-blue-400">View Details</button>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <>
            <div className="hidden lg:block overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-neutral-800">
                <thead className="bg-gray-50 dark:bg-neutral-900/80">
                  <tr>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Hospital & Location</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Requirements</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Urgency</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Posted By</th>
                    <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                    <th scope="col" className="relative px-6 py-3.5 text-right text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-neutral-900 divide-y divide-gray-100 dark:divide-neutral-800/50">
                  {filteredRequests.length === 0 ? (
                    <tr><td colSpan="6" className="px-6 py-12 text-center text-gray-500 dark:text-neutral-400">No blood requests found.</td></tr>
                  ) : filteredRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-gray-50 dark:hover:bg-neutral-800/30 transition-colors group">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-bold text-gray-900 dark:text-white flex items-center">
                          <Hospital size={14} className="mr-1.5 text-gray-400" /> {req.hospital}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-neutral-400 mt-1 flex items-center">
                          <MapPin size={12} className="mr-1.5" /> {req.location}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center justify-center px-2 py-1 rounded bg-red-100 text-red-700 font-bold text-sm dark:bg-red-500/20 dark:text-red-400 border border-red-200 dark:border-red-500/30">
                            {req.bloodGroup}
                          </span>
                          <span className="text-sm font-medium text-gray-700 dark:text-neutral-300">{req.units} Unit(s)</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap"><UrgencyBadge urgency={req.urgency} /></td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <img className="h-6 w-6 rounded-full border border-gray-200 dark:border-neutral-700 object-cover mr-2" src={req.posterAvatar} alt="" />
                          <div className="text-sm text-gray-900 dark:text-neutral-200">{req.posterName}</div>
                        </div>
                        <div className="text-xs text-gray-400 dark:text-neutral-500 mt-0.5">{req.timePosted}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap"><StatusIndicator status={req.status} /></td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end space-x-3">
                          <button onClick={() => setSelectedBloodRequest(req)} className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 font-medium px-2">View</button>
                          <div className="hidden group-hover:flex items-center space-x-2 border-l border-gray-200 dark:border-neutral-800 pl-3">
                            {req.status === 'Active' && (
                              <button className="text-emerald-600 hover:text-emerald-700 dark:text-emerald-500 dark:hover:text-emerald-400 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:hover:bg-emerald-500/20 p-1.5 rounded" title="Mark Resolved"><CheckCircle size={16} /></button>
                            )}
                            <button className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 bg-red-50 hover:bg-red-100 dark:bg-red-500/10 dark:hover:bg-red-500/20 p-1.5 rounded" title="Remove Post"><X size={16} /></button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="lg:hidden divide-y divide-gray-200 dark:divide-neutral-800">
              {filteredRequests.map((req) => (
                <div key={req.id} className="p-5 hover:bg-gray-50 dark:hover:bg-neutral-800/30 transition-colors">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center">
                         <Hospital size={14} className="mr-1.5 text-gray-400" /> {req.hospital}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1 flex items-center"><MapPin size={12} className="mr-1.5" /> {req.location}</p>
                    </div>
                    <StatusIndicator status={req.status} />
                  </div>
                  <div className="flex items-center gap-3 my-4">
                    <span className="inline-flex items-center justify-center px-2 py-1 rounded bg-red-100 text-red-700 font-bold text-sm dark:bg-red-500/20 dark:text-red-400 border border-red-200 dark:border-red-500/30">
                      {req.bloodGroup} • {req.units} Unit(s)
                    </span>
                    <UrgencyBadge urgency={req.urgency} />
                  </div>
                  <div className="flex items-center justify-between border-t border-gray-100 dark:border-neutral-800/50 pt-4 gap-3">
                     <div className="flex items-center">
                        <img className="h-6 w-6 rounded-full border border-gray-200 dark:border-neutral-700 object-cover mr-2" src={req.posterAvatar} alt="" />
                        <div className="text-xs text-gray-600 dark:text-neutral-400">By {req.posterName}</div>
                     </div>
                     <button onClick={() => setSelectedBloodRequest(req)} className="text-sm font-medium text-blue-600 dark:text-blue-400 px-3 py-1.5 bg-blue-50 dark:bg-blue-900/20 rounded-md">Review Details</button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

const AdsView = ({ setSelectedAd }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [placementFilter, setPlacementFilter] = useState("All");

  const filteredAds = useMemo(() => {
    return mockAds.filter(ad => {
      const matchesSearch = ad.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "All" || ad.status === statusFilter;
      const matchesPlacement = placementFilter === "All" || ad.placement === placementFilter;
      return matchesSearch && matchesStatus && matchesPlacement;
    });
  }, [searchQuery, statusFilter, placementFilter]);

  const handleCreateNewAd = () => {
    setSelectedAd({ isNew: true, title: '', img: '', link: '', placement: 'Home Banner', status: 'Draft', startDate: '', endDate: '', notes: '' });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Ads Management</h1>
          <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">Manage promotional poster banners shown in the app</p>
        </div>
        <button onClick={handleCreateNewAd} className="inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-neutral-900 transition-colors">
          <Plus size={16} className="mr-2" /> Create New Ad
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Active Ads", value: mockAds.filter(a => a.status === 'Active').length, color: "text-emerald-600 dark:text-emerald-400" },
          { label: "Scheduled Ads", value: mockAds.filter(a => a.status === 'Scheduled').length, color: "text-blue-600 dark:text-blue-400" },
          { label: "Expired Ads", value: mockAds.filter(a => a.status === 'Expired').length, color: "text-gray-600 dark:text-neutral-400" },
          { label: "Total Campaigns", value: mockAds.length, color: "text-gray-900 dark:text-white" }
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-4 flex flex-col justify-center">
            <span className="text-xs font-medium text-gray-500 dark:text-neutral-400 uppercase tracking-wider">{stat.label}</span>
            <span className={`text-2xl font-bold mt-1 ${stat.color}`}>{stat.value}</span>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-800 rounded-xl overflow-hidden transition-all duration-300">
        <div className="p-4 border-b border-gray-200 dark:border-neutral-800 bg-gray-50/50 dark:bg-neutral-900/50 flex flex-col lg:flex-row gap-4 items-center">
          <div className="relative w-full lg:flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Search className="h-4 w-4 text-gray-400 dark:text-neutral-500" /></div>
            <input type="text" placeholder="Search by campaign title..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg leading-5 bg-white dark:bg-neutral-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Filter className="h-3.5 w-3.5 text-gray-400 dark:text-neutral-500" /></div>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="block w-full sm:w-36 pl-9 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Status</option><option value="Active">Active</option><option value="Scheduled">Scheduled</option><option value="Expired">Expired</option><option value="Draft">Draft</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>

            <div className="relative flex-1 sm:flex-none">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><MonitorUp className="h-3.5 w-3.5 text-gray-400 dark:text-neutral-500" /></div>
              <select value={placementFilter} onChange={(e) => setPlacementFilter(e.target.value)} className="block w-full sm:w-44 pl-9 pr-8 py-2 text-sm border border-gray-300 dark:border-neutral-700 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white appearance-none cursor-pointer">
                <option value="All">All Placements</option><option value="Home Banner">Home Banner</option><option value="Jobs Section">Jobs Section</option><option value="Other">Other</option>
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-neutral-400 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="hidden lg:block overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-neutral-800">
            <thead className="bg-gray-50 dark:bg-neutral-900/80">
              <tr>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Poster Preview</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Campaign Details</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Schedule</th>
                <th scope="col" className="px-6 py-3.5 text-left text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                <th scope="col" className="relative px-6 py-3.5 text-right text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-neutral-900 divide-y divide-gray-100 dark:divide-neutral-800/50">
              {filteredAds.length === 0 ? (
                <tr><td colSpan="5" className="px-6 py-12 text-center text-gray-500 dark:text-neutral-400">No ads found.</td></tr>
              ) : filteredAds.map((ad) => (
                <tr key={ad.id} className="hover:bg-gray-50 dark:hover:bg-neutral-800/30 transition-colors group">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="w-28 aspect-[21/9] rounded-md overflow-hidden border border-gray-200 dark:border-neutral-700 bg-gray-100 dark:bg-neutral-800">
                      {ad.img ? <img src={ad.img} alt={ad.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-gray-400"><ImageIcon size={16} /></div>}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-bold text-gray-900 dark:text-white">{ad.title}</div>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="inline-flex text-xs font-medium text-gray-500 dark:text-neutral-400 bg-gray-100 dark:bg-neutral-800/50 px-2 py-0.5 rounded-md"><MonitorUp size={10} className="mr-1 mt-0.5" /> {ad.placement}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-700 dark:text-neutral-300 flex items-center"><CalendarDays size={14} className="mr-1.5 text-gray-400" /> {ad.startDate}</div>
                    <div className="text-sm text-gray-500 dark:text-neutral-500 flex items-center mt-1 pl-5">to {ad.endDate}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap"><StatusIndicator status={ad.status} /></td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-2">
                      <button onClick={() => setSelectedAd(ad)} className="text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 p-1.5 rounded-md hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors" title="Edit Campaign"><Edit3 size={18} /></button>
                      {ad.status === 'Active' ? (
                        <button className="text-gray-400 hover:text-amber-600 dark:hover:text-amber-400 p-1.5 rounded-md hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors" title="Deactivate"><Pause size={18} /></button>
                      ) : (
                        <button className="text-gray-400 hover:text-emerald-600 dark:hover:text-emerald-400 p-1.5 rounded-md hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors" title="Activate"><Play size={18} /></button>
                      )}
                      <div className="w-px h-4 bg-gray-200 dark:bg-neutral-800 mx-1 hidden group-hover:block transition-all"></div>
                      <button className="text-gray-400 hover:text-red-600 dark:hover:text-red-400 hidden group-hover:block p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20 transition-all" title="Delete"><Trash2 size={18} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="lg:hidden divide-y divide-gray-200 dark:divide-neutral-800">
          {filteredAds.map((ad) => (
            <div key={ad.id} className="p-5 hover:bg-gray-50 dark:hover:bg-neutral-800/30 transition-colors">
              <div className="w-full aspect-[21/9] rounded-lg overflow-hidden border border-gray-200 dark:border-neutral-700 bg-gray-100 dark:bg-neutral-800 mb-4">
                {ad.img ? <img src={ad.img} alt={ad.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-gray-400"><ImageIcon size={24} /></div>}
              </div>
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-base font-bold text-gray-900 dark:text-white leading-tight">{ad.title}</h3>
                <StatusIndicator status={ad.status} />
              </div>
              <div className="flex items-center gap-2 mb-3">
                 <span className="inline-flex items-center text-xs font-medium text-gray-500 dark:text-neutral-400 bg-gray-100 dark:bg-neutral-800/50 px-2 py-0.5 rounded-md"><MonitorUp size={10} className="mr-1" /> {ad.placement}</span>
              </div>
              <div className="text-sm text-gray-600 dark:text-neutral-400 flex items-center mb-4">
                <CalendarDays size={14} className="mr-1.5 text-gray-400" /> {ad.startDate} — {ad.endDate}
              </div>
              <div className="flex items-center justify-between border-t border-gray-100 dark:border-neutral-800/50 pt-4 gap-3">
                <button onClick={() => setSelectedAd(ad)} className="flex-1 inline-flex justify-center items-center px-3 py-2 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors dark:bg-blue-500/10 dark:text-blue-400 dark:hover:bg-blue-500/20"><Edit3 size={16} className="mr-1.5" /> Edit</button>
                <button className="flex-1 inline-flex justify-center items-center px-3 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors dark:bg-neutral-800 dark:text-neutral-300 dark:hover:bg-neutral-700">
                  {ad.status === 'Active' ? <><Pause size={16} className="mr-1.5" /> Pause</> : <><Play size={16} className="mr-1.5" /> Activate</>}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const ReportsView = () => {
  const [dateRange, setDateRange] = useState("Last 30 days");

  const DistributionBar = ({ label, value, color, total }) => {
    const percentage = Math.round((value / total) * 100);
    return (
      <div className="mb-4 last:mb-0">
        <div className="flex justify-between text-sm mb-1.5">
          <span className="font-medium text-gray-700 dark:text-neutral-300">{label}</span>
          <span className="text-gray-500 dark:text-neutral-400">{percentage}% <span className="text-xs">({value})</span></span>
        </div>
        <div className="w-full bg-gray-100 dark:bg-neutral-800/50 rounded-full h-2.5 overflow-hidden">
          <div className={`h-2.5 rounded-full ${color}`} style={{ width: `${percentage}%` }}></div>
        </div>
      </div>
    );
  };

  const ReportsLineChart = () => {
    const points = [10, 25, 20, 45, 35, 60, 50, 80, 75, 95];
    const max = Math.max(...points);
    const width = 100;
    const height = 40;
    const stepX = width / (points.length - 1);
    
    const pathData = points.map((val, i) => {
      const x = i * stepX;
      const y = height - ((val / max) * height * 0.8);
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');

    const areaData = `${pathData} L ${width} ${height} L 0 ${height} Z`;

    return (
      <div className="w-full h-48 mt-6 relative">
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-5">
          {[4, 3, 2, 1, 0].map(i => (
            <div key={i} className="flex items-center w-full">
              <span className="text-[10px] text-gray-400 w-8">{i * 25}</span>
              <div className="flex-1 border-t border-dashed border-gray-200 dark:border-neutral-800"></div>
            </div>
          ))}
        </div>
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible ml-8" style={{ width: 'calc(100% - 2rem)' }} preserveAspectRatio="none">
          <defs>
            <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={areaData} fill="url(#areaGrad)" />
          <path d={pathData} fill="none" stroke="#3b82f6" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          {points.map((val, i) => (
            <circle key={i} cx={i * stepX} cy={height - ((val / max) * height * 0.8)} r="1.5" fill="#3b82f6" className="opacity-0 hover:opacity-100 transition-opacity cursor-pointer stroke-white dark:stroke-neutral-900 stroke-[0.5]" />
          ))}
        </svg>
        <div className="absolute bottom-0 left-8 right-0 flex justify-between text-[10px] text-gray-400">
           <span>W1</span><span>W2</span><span>W3</span><span>W4</span><span>W5</span>
        </div>
      </div>
    );
  };

  const ReportsBarChart = () => {
    const data = [12, 35, 24, 45, 28, 55, 42];
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const max = Math.max(...data);

    return (
      <div className="w-full h-48 mt-6 relative">
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-5">
          {[4, 3, 2, 1, 0].map(i => (
            <div key={i} className="flex items-center w-full">
              <span className="text-[10px] text-gray-400 w-6">{Math.round(max * (i/4))}</span>
              <div className="flex-1 border-t border-gray-100 dark:border-neutral-800/50"></div>
            </div>
          ))}
        </div>
        <div className="absolute inset-0 ml-6 pb-5 flex items-end justify-between px-2 gap-2 sm:gap-4">
           {data.map((val, i) => (
              <div key={i} className="relative flex-1 group h-full flex items-end justify-center">
                <div 
                  className="w-full max-w-[24px] bg-purple-200 dark:bg-purple-900/40 rounded-t-sm transition-all duration-300 group-hover:bg-purple-300 dark:group-hover:bg-purple-800/60 relative"
                  style={{ height: `${(val / max) * 100}%` }}
                >
                  <div className="absolute bottom-0 w-full bg-purple-600 dark:bg-purple-500 rounded-t-sm opacity-90 transition-all duration-300 group-hover:opacity-100" style={{ height: '70%' }}></div>
                  <div className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-gray-800 text-white text-[10px] py-1 px-2 rounded pointer-events-none transition-opacity whitespace-nowrap">
                     {val} Jobs
                  </div>
                </div>
              </div>
           ))}
        </div>
        <div className="absolute bottom-0 left-6 right-0 flex justify-between px-2">
           {labels.map((l, i) => (
              <span key={i} className="text-[10px] text-gray-400 flex-1 text-center truncate">{l}</span>
           ))}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Reports & Analytics</h1>
          <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">Track platform activity and key performance metrics</p>
        </div>
        <div className="relative">
           <div className="flex items-center bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-800 rounded-lg p-1">
              {['Last 7 days', 'Last 30 days', 'Last 90 days'].map(range => (
                <button key={range} onClick={() => setDateRange(range)} className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${dateRange === range ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'text-gray-500 hover:text-gray-900 dark:text-neutral-400 dark:hover:text-neutral-200'}`}>
                  {range}
                </button>
              ))}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Users", value: "12,450", icon: Users, color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-500/10" },
          { label: "Verified Alumni", value: "8,230", icon: GraduationCap, color: "text-indigo-600 dark:text-indigo-400", bg: "bg-indigo-50 dark:bg-indigo-500/10" },
          { label: "Total Jobs Posted", value: "1,204", icon: Briefcase, color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-50 dark:bg-purple-500/10" },
          { label: "Active Blood Donors", value: "3,405", icon: HeartPulse, color: "text-red-600 dark:text-red-400", bg: "bg-red-50 dark:bg-red-500/10" },
          { label: "Pending Verifications", value: "156", icon: Shield, color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-500/10" },
          { label: "Pending Job Approvals", value: "24", icon: Clock, color: "text-orange-600 dark:text-orange-400", bg: "bg-orange-50 dark:bg-orange-500/10" },
          { label: "Active Emergencies", value: "12", icon: AlertTriangle, color: "text-rose-600 dark:text-rose-400", bg: "bg-rose-50 dark:bg-rose-500/10" },
          { label: "Suspended Users", value: "18", icon: Ban, color: "text-gray-600 dark:text-neutral-400", bg: "bg-gray-100 dark:bg-neutral-900" },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-4 flex flex-col justify-center">
            <div className="flex items-start justify-between">
               <div>
                  <span className="text-xs font-medium text-gray-500 dark:text-neutral-400 uppercase tracking-wider">{stat.label}</span>
                  <span className="block text-2xl font-bold mt-1 text-gray-900 dark:text-white">{stat.value}</span>
               </div>
               <div className={`p-2 rounded-lg ${stat.bg}`}><stat.icon size={18} className={stat.color} /></div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
         <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-5">
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-neutral-800/50 pb-4">
               <div>
                  <h3 className="text-base font-semibold text-gray-900 dark:text-white">New Users Growth</h3>
                  <p className="text-xs text-gray-500 dark:text-neutral-400 mt-0.5">Overall account registrations over time</p>
               </div>
               <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">
                  <TrendingUp size={12} className="mr-1" /> +14.5%
               </span>
            </div>
            <ReportsLineChart />
         </div>

         <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-5">
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-neutral-800/50 pb-4">
               <div>
                  <h3 className="text-base font-semibold text-gray-900 dark:text-white">Jobs Posted</h3>
                  <p className="text-xs text-gray-500 dark:text-neutral-400 mt-0.5">Daily volume of job board submissions</p>
               </div>
               <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">
                  <TrendingUp size={12} className="mr-1" /> +8.2%
               </span>
            </div>
            <ReportsBarChart />
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
         <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-5">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
               <PieChart size={16} className="mr-2 text-gray-400" /> Role Distribution
            </h3>
            <div className="space-y-1">
               <DistributionBar label="Students" value={8500} total={12450} color="bg-blue-500" />
               <DistributionBar label="Alumni" value={3200} total={12450} color="bg-purple-500" />
               <DistributionBar label="Faculty" value={650} total={12450} color="bg-amber-500" />
               <DistributionBar label="Admins" value={100} total={12450} color="bg-gray-500" />
            </div>
         </div>

         <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-5">
            <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
               <Shield size={16} className="mr-2 text-gray-400" /> Status Breakdown
            </h3>
            <div className="mb-5">
               <p className="text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider mb-3 border-b border-gray-100 dark:border-neutral-800/50 pb-1">Alumni Verification</p>
               <DistributionBar label="Verified" value={8230} total={8500} color="bg-emerald-500" />
               <DistributionBar label="Pending" value={156} total={8500} color="bg-amber-500" />
               <DistributionBar label="Rejected" value={114} total={8500} color="bg-red-500" />
            </div>
            <div>
               <p className="text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider mb-3 border-b border-gray-100 dark:border-neutral-800/50 pb-1">Job Approvals</p>
               <DistributionBar label="Approved" value={1050} total={1204} color="bg-emerald-500" />
               <DistributionBar label="Pending" value={24} total={1204} color="bg-amber-500" />
               <DistributionBar label="Rejected" value={130} total={1204} color="bg-red-500" />
            </div>
         </div>

         <div className="bg-white dark:bg-neutral-900 rounded-xl border border-gray-200 dark:border-neutral-800 p-0 flex flex-col">
            <div className="px-5 py-4 border-b border-gray-200 dark:border-neutral-800">
               <h3 className="text-base font-semibold text-gray-900 dark:text-white flex items-center">
                  <Activity size={16} className="mr-2 text-gray-400" /> Today's Activity
               </h3>
            </div>
            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
               <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30">
                  <div className="flex items-center">
                     <div className="p-2 bg-blue-100 dark:bg-blue-900/40 rounded-md text-blue-600 dark:text-blue-400 mr-3"><Users size={16} /></div>
                     <span className="text-sm font-medium text-gray-700 dark:text-neutral-300">New Users Joined</span>
                  </div>
                  <span className="text-lg font-bold text-gray-900 dark:text-white">42</span>
               </div>
               <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50/50 dark:bg-purple-900/10 border border-purple-100 dark:border-purple-900/30">
                  <div className="flex items-center">
                     <div className="p-2 bg-purple-100 dark:bg-purple-900/40 rounded-md text-purple-600 dark:text-purple-400 mr-3"><Briefcase size={16} /></div>
                     <span className="text-sm font-medium text-gray-700 dark:text-neutral-300">Jobs Submitted</span>
                  </div>
                  <span className="text-lg font-bold text-gray-900 dark:text-white">15</span>
               </div>
               <div className="flex items-center justify-between p-3 rounded-lg bg-red-50/50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30">
                  <div className="flex items-center">
                     <div className="p-2 bg-red-100 dark:bg-red-900/40 rounded-md text-red-600 dark:text-red-400 mr-3"><AlertTriangle size={16} /></div>
                     <span className="text-sm font-medium text-gray-700 dark:text-neutral-300">Emergency Requests</span>
                  </div>
                  <span className="text-lg font-bold text-gray-900 dark:text-white">3</span>
               </div>
               <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50/50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30">
                  <div className="flex items-center">
                     <div className="p-2 bg-amber-100 dark:bg-amber-900/40 rounded-md text-amber-600 dark:text-amber-400 mr-3"><Megaphone size={16} /></div>
                     <span className="text-sm font-medium text-gray-700 dark:text-neutral-300">Active Ad Campaigns</span>
                  </div>
                  <span className="text-lg font-bold text-gray-900 dark:text-white">5</span>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

// ==========================================
// MAIN APP COMPONENT
// ==========================================

const App = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('Dashboard'); 
  
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedVerification, setSelectedVerification] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null);
  const [selectedBloodRequest, setSelectedBloodRequest] = useState(null);
  const [selectedDonor, setSelectedDonor] = useState(null);
  const [selectedAd, setSelectedAd] = useState(null); 

  // --- SMART DARK MODE HOOK ---
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Check localStorage or system preference on initial load
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme) {
        return savedTheme === 'dark';
      }
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  return (
    <>
      <style dangerouslySetInnerHTML={{__html: `
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
      `}} />
      <div className="flex h-screen bg-gray-50 dark:bg-neutral-950 text-gray-900 dark:text-neutral-100 overflow-hidden transition-colors duration-200" style={{ fontFamily: '"Plus Jakarta Sans", sans-serif' }}>
        
        {isMobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-gray-900/40 dark:bg-neutral-950/60 backdrop-blur-sm z-20 lg:hidden transition-opacity"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}
        
        <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-white dark:bg-neutral-900 border-r border-gray-200 dark:border-neutral-800 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-auto flex flex-col ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200 dark:border-neutral-800">
            <div className="text-xl font-bold tracking-tight text-blue-900 dark:text-blue-100">NSU<span className="text-blue-600 dark:text-blue-400">NEXT</span></div>
            <button className="lg:hidden text-gray-500 hover:text-gray-700 dark:text-neutral-400 dark:hover:text-neutral-200" onClick={() => setIsMobileMenuOpen(false)}>
              <X size={20} />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto py-4">
            <nav className="space-y-1 px-3">
              {navItems.map((item) => {
                const isActive = activeTab === item.name || (activeTab === 'Dashboard' && item.name === 'Dashboard');
                return (
                  <button
                    key={item.name}
                    onClick={() => {
                      if(['Dashboard', 'Users', 'Alumni Verification', 'Jobs', 'Emergency Support', 'Ads', 'Reports'].includes(item.name)) {
                        setActiveTab(item.name);
                      }
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400' 
                        : 'text-gray-700 dark:text-neutral-300 hover:bg-gray-100 dark:hover:bg-neutral-800/50'
                    }`}
                  >
                    <item.icon className={`mr-3 h-5 w-5 ${isActive ? 'text-blue-700 dark:text-blue-400' : 'text-gray-400 dark:text-neutral-500'}`} />
                    {item.name}
                  </button>
                )
              })}
            </nav>
          </div>
          
          <div className="p-4 border-t border-gray-200 dark:border-neutral-800">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-700 dark:text-blue-300 font-bold text-sm">
                AD
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700 dark:text-neutral-200">Admin Portal</p>
                <p className="text-xs text-gray-500 dark:text-neutral-400">v2.4.1</p>
              </div>
            </div>
          </div>
        </aside>

        <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
          
          <header className="h-16 bg-white dark:bg-neutral-900 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between px-4 sm:px-6 z-10 transition-colors duration-200">
            <div className="flex items-center">
              <button 
                className="text-gray-500 hover:text-gray-700 dark:text-neutral-400 dark:hover:text-neutral-200 focus:outline-none lg:hidden mr-4"
                onClick={() => setIsMobileMenuOpen(true)}
              >
                <Menu size={24} />
              </button>
              
              <div className="relative hidden sm:block">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400 dark:text-neutral-500" />
                </div>
                <input 
                  type="text" 
                  placeholder="Global search..." 
                  className="block w-full pl-10 pr-3 py-2 border border-gray-200 dark:border-neutral-800 rounded-lg leading-5 bg-gray-50 dark:bg-neutral-950 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-neutral-500 focus:outline-none focus:bg-white dark:focus:bg-neutral-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2 sm:space-x-4">
              <button 
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="p-2 text-gray-400 hover:text-gray-500 dark:hover:text-neutral-300 transition-colors rounded-full hover:bg-gray-100 dark:hover:bg-neutral-800"
                aria-label="Toggle Dark Mode"
              >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
              </button>
              
              <button className="relative p-2 text-gray-400 hover:text-gray-500 dark:hover:text-neutral-300 transition-colors rounded-full hover:bg-gray-100 dark:hover:bg-neutral-800">
                <Bell size={20} />
                <span className="absolute top-1.5 right-1.5 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white dark:ring-neutral-900"></span>
              </button>
              
              <div className="flex items-center cursor-pointer pl-2 border-l border-gray-200 dark:border-neutral-800">
                <img 
                  className="h-8 w-8 rounded-full border border-gray-200 dark:border-neutral-700 object-cover"
                  src="https://i.pravatar.cc/150?u=admin" 
                  alt="Admin avatar" 
                />
                <div className="hidden md:flex ml-2 items-center">
                  <span className="text-sm font-medium text-gray-700 dark:text-neutral-200">Fahim R.</span>
                  <ChevronDown size={16} className="ml-1 text-gray-400 dark:text-neutral-500" />
                </div>
              </div>
            </div>
          </header>

          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-neutral-950 p-4 sm:p-6 transition-colors duration-200">
             {activeTab === 'Dashboard' && <DashboardView setActiveTab={setActiveTab} />}
             {activeTab === 'Users' && <UsersView setSelectedUser={setSelectedUser} />}
             {activeTab === 'Alumni Verification' && <AlumniVerificationView setSelectedVerification={setSelectedVerification} />}
             {activeTab === 'Jobs' && <JobsView setSelectedJob={setSelectedJob} />}
             {activeTab === 'Emergency Support' && <EmergencySupportView setSelectedDonor={setSelectedDonor} setSelectedBloodRequest={setSelectedBloodRequest} />}
             {activeTab === 'Ads' && <AdsView setSelectedAd={setSelectedAd} />}
             {activeTab === 'Reports' && <ReportsView />}
          </main>

          {/* OVERLAYS */}
          
          {selectedUser && (
            <div className="fixed inset-0 z-50 overflow-hidden">
              <div className="absolute inset-0 bg-gray-900/40 dark:bg-neutral-950/60 backdrop-blur-sm transition-opacity" onClick={() => setSelectedUser(null)} />
              <div className="absolute inset-y-0 right-0 max-w-full flex">
                <div className="w-full md:w-96 bg-white dark:bg-neutral-900 shadow-xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
                  <div className="px-6 py-4 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between bg-gray-50 dark:bg-neutral-900/80">
                    <h2 className="text-lg font-semibold text-gray-900 dark:text-white">User Profile</h2>
                    <button onClick={() => setSelectedUser(null)} className="text-gray-400 hover:text-gray-500 dark:hover:text-neutral-300"><X size={20} /></button>
                  </div>

                  <div className="flex-1 overflow-y-auto p-6">
                    <div className="flex flex-col items-center text-center mb-8">
                      <div className="relative">
                        <img className="h-24 w-24 rounded-full border-4 border-white dark:border-neutral-800 object-cover" src={selectedUser.avatar} alt="" />
                        {selectedUser.verification === 'Verified' && <div className="absolute bottom-0 right-0 bg-white dark:bg-neutral-900 rounded-full p-0.5"><CheckCircle2 size={24} className="text-blue-500" /></div>}
                      </div>
                      <h3 className="mt-4 text-xl font-bold text-gray-900 dark:text-white">{selectedUser.name}</h3>
                      <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">{selectedUser.email}</p>
                      <div className="mt-3 flex gap-2">
                        <Badge type={selectedUser.role}>{selectedUser.role}</Badge>
                        <Badge type={selectedUser.status}>{selectedUser.status}</Badge>
                      </div>
                    </div>
                    <div className="space-y-4 border-t border-gray-200 dark:border-neutral-800 pt-6">
                      <h4 className="text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase tracking-wider mb-2">Account Details</h4>
                      <div className="flex items-start"><Building size={18} className="text-gray-400 dark:text-neutral-500 mt-0.5 mr-3" /><div><p className="text-sm font-medium text-gray-900 dark:text-white">Department</p><p className="text-sm text-gray-500 dark:text-neutral-400">{selectedUser.department}</p></div></div>
                      {selectedUser.batch && <div className="flex items-start"><GraduationCap size={18} className="text-gray-400 dark:text-neutral-500 mt-0.5 mr-3" /><div><p className="text-sm font-medium text-gray-900 dark:text-white">Batch</p><p className="text-sm text-gray-500 dark:text-neutral-400">{selectedUser.batch}</p></div></div>}
                      <div className="flex items-start"><Shield size={18} className="text-gray-400 dark:text-neutral-500 mt-0.5 mr-3" /><div><p className="text-sm font-medium text-gray-900 dark:text-white">Verification</p><p className="text-sm text-gray-500 dark:text-neutral-400">{selectedUser.verification}</p></div></div>
                      <div className="flex items-start"><Calendar size={18} className="text-gray-400 dark:text-neutral-500 mt-0.5 mr-3" /><div><p className="text-sm font-medium text-gray-900 dark:text-white">Joined Date</p><p className="text-sm text-gray-500 dark:text-neutral-400">{selectedUser.joinDate}</p></div></div>
                    </div>
                  </div>

                  <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-gray-50 dark:bg-neutral-900/80">
                    {selectedUser.status === 'Suspended' ? (
                      <button className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"><CheckCircle size={18} className="mr-2" /> Reactivate Account</button>
                    ) : (
                      <button className="w-full flex justify-center items-center px-4 py-2 border border-red-200 dark:border-red-900/50 rounded-lg text-sm font-medium text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 dark:hover:bg-red-500/20 transition-colors"><Ban size={18} className="mr-2" /> Suspend Account</button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {selectedVerification && (
            <div className="fixed inset-0 z-50 overflow-hidden">
              <div className="absolute inset-0 bg-gray-900/40 dark:bg-neutral-950/60 backdrop-blur-sm transition-opacity" onClick={() => setSelectedVerification(null)} />
              <div className="absolute inset-y-0 right-0 max-w-full flex">
                <div className="w-full md:w-[600px] bg-white dark:bg-neutral-900 shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
                  <div className="px-6 py-4 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between bg-white dark:bg-neutral-900 z-10">
                    <div>
                      <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Document Review</h2>
                      <p className="text-sm text-gray-500 dark:text-neutral-400">ID: NSU-VER-{selectedVerification.id}</p>
                    </div>
                    <button onClick={() => setSelectedVerification(null)} className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-neutral-300 rounded-full hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors"><X size={20} /></button>
                  </div>
                  <div className="flex-1 overflow-y-auto">
                    <div className="bg-gray-200 dark:bg-black p-6 flex justify-center items-center min-h-[400px] relative border-b border-gray-200 dark:border-neutral-800">
                      <div className="relative group w-full h-full flex justify-center">
                        <img src={selectedVerification.certImg} alt="Certificate" className="max-w-full h-auto max-h-[500px] rounded border border-gray-300 dark:border-neutral-800 object-contain bg-white" />
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex items-center space-x-4 mb-6">
                        <img className="h-14 w-14 rounded-full border border-gray-200 dark:border-neutral-700 object-cover" src={selectedVerification.avatar} alt="" />
                        <div><h3 className="text-lg font-bold text-gray-900 dark:text-white">{selectedVerification.name}</h3><p className="text-sm text-gray-500 dark:text-neutral-400">{selectedVerification.email}</p></div>
                        <div className="ml-auto"><StatusIndicator status={selectedVerification.status} /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="bg-gray-50 dark:bg-neutral-800/50 p-3 rounded-lg border border-gray-100 dark:border-neutral-800/50"><p className="text-xs text-gray-500 dark:text-neutral-400 uppercase font-medium">Department</p><p className="text-sm font-semibold text-gray-900 dark:text-white mt-0.5">{selectedVerification.department}</p></div>
                        <div className="bg-gray-50 dark:bg-neutral-800/50 p-3 rounded-lg border border-gray-100 dark:border-neutral-800/50"><p className="text-xs text-gray-500 dark:text-neutral-400 uppercase font-medium">Batch</p><p className="text-sm font-semibold text-gray-900 dark:text-white mt-0.5">{selectedVerification.batch}</p></div>
                        <div className="col-span-2 bg-gray-50 dark:bg-neutral-800/50 p-3 rounded-lg border border-gray-100 dark:border-neutral-800/50"><p className="text-xs text-gray-500 dark:text-neutral-400 uppercase font-medium">Submitted</p><p className="text-sm font-semibold text-gray-900 dark:text-white mt-0.5 flex items-center"><Clock size={14} className="mr-1.5 text-gray-400" /> {selectedVerification.submitDate}</p></div>
                      </div>
                    </div>
                  </div>
                  {selectedVerification.status === 'Pending' ? (
                    <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
                      <div className="grid grid-cols-2 gap-3">
                        <button className="flex justify-center items-center px-4 py-2.5 border border-red-200 dark:border-red-900/50 rounded-lg text-sm font-bold text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 transition-colors"><X size={18} className="mr-2" /> Reject</button>
                        <button className="flex justify-center items-center px-4 py-2.5 border border-transparent rounded-lg text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"><Check size={18} className="mr-2" /> Approve</button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-gray-50 dark:bg-neutral-900/80 text-center"><p className="text-sm text-gray-500 dark:text-neutral-400 font-medium">This application is already {selectedVerification.status}.</p></div>
                  )}
                </div>
              </div>
            </div>
          )}

          {selectedJob && (
            <div className="fixed inset-0 z-50 overflow-hidden">
              <div className="absolute inset-0 bg-gray-900/40 dark:bg-neutral-950/60 backdrop-blur-sm transition-opacity" onClick={() => setSelectedJob(null)} />
              <div className="absolute inset-y-0 right-0 max-w-full flex">
                <div className="w-full md:w-[600px] bg-white dark:bg-neutral-900 shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
                  <div className="px-6 py-4 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between bg-gray-50 dark:bg-neutral-900/80 z-10">
                    <div>
                      <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Job Preview</h2>
                      <p className="text-sm text-gray-500 dark:text-neutral-400">ID: NSU-JOB-{selectedJob.id}</p>
                    </div>
                    <button onClick={() => setSelectedJob(null)} className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-neutral-300 rounded-full hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors"><X size={20} /></button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-6">
                    <div className="flex items-start justify-between mb-8">
                      <div><h1 className="text-2xl font-bold text-gray-900 dark:text-white leading-tight">{selectedJob.title}</h1><p className="text-lg text-blue-600 dark:text-blue-400 font-medium mt-1">{selectedJob.company}</p></div>
                      <StatusIndicator status={selectedJob.status} />
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-8">
                      <div className="flex items-start p-3 bg-gray-50 dark:bg-neutral-800/50 rounded-lg"><Briefcase size={18} className="text-gray-400 mt-0.5 mr-3" /><div><p className="text-xs text-gray-500 dark:text-neutral-400 uppercase">Job Type</p><p className="text-sm font-medium text-gray-900 dark:text-white">{selectedJob.type}</p></div></div>
                      <div className="flex items-start p-3 bg-gray-50 dark:bg-neutral-800/50 rounded-lg"><MapPin size={18} className="text-gray-400 mt-0.5 mr-3" /><div><p className="text-xs text-gray-500 dark:text-neutral-400 uppercase">Location</p><p className="text-sm font-medium text-gray-900 dark:text-white">{selectedJob.location}</p></div></div>
                      <div className="flex items-start p-3 bg-gray-50 dark:bg-neutral-800/50 rounded-lg"><Building size={18} className="text-gray-400 mt-0.5 mr-3" /><div><p className="text-xs text-gray-500 dark:text-neutral-400 uppercase">Department</p><p className="text-sm font-medium text-gray-900 dark:text-white">{selectedJob.department}</p></div></div>
                      <div className="flex items-start p-3 bg-gray-50 dark:bg-neutral-800/50 rounded-lg"><Calendar size={18} className="text-gray-400 mt-0.5 mr-3" /><div><p className="text-xs text-gray-500 dark:text-neutral-400 uppercase">Deadline</p><p className="text-sm font-medium text-gray-900 dark:text-white">{selectedJob.deadline}</p></div></div>
                    </div>
                    <div className="mb-8">
                      <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-3 border-b border-gray-200 dark:border-neutral-800 pb-2">Description</h3>
                      <p className="text-sm text-gray-600 dark:text-neutral-300 leading-relaxed whitespace-pre-wrap">{selectedJob.description}</p>
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-3 border-b border-gray-200 dark:border-neutral-800 pb-2">Submitted By</h3>
                      <div className="flex items-center space-x-4 p-4 rounded-lg bg-gray-50 dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700">
                        <img className="h-12 w-12 rounded-full border border-gray-200 dark:border-neutral-600 object-cover" src={selectedJob.posterAvatar} alt="" />
                        <div><p className="text-sm font-bold text-gray-900 dark:text-white">{selectedJob.posterName}</p><p className="text-xs text-gray-500 dark:text-neutral-400 mt-0.5">Submitted on {selectedJob.submitDate}</p></div>
                      </div>
                    </div>
                  </div>
                  {selectedJob.status === 'Pending' ? (
                    <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
                      <div className="grid grid-cols-2 gap-3">
                        <button className="flex justify-center items-center px-4 py-2.5 border border-red-200 dark:border-red-900/50 rounded-lg text-sm font-bold text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 transition-colors"><X size={18} className="mr-2" /> Reject Job</button>
                        <button className="flex justify-center items-center px-4 py-2.5 rounded-lg text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"><Check size={18} className="mr-2" /> Approve Job</button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-gray-50 dark:bg-neutral-900/80 text-center"><p className="text-sm text-gray-500 dark:text-neutral-400 font-medium">Already {selectedJob.status}.</p></div>
                  )}
                </div>
              </div>
            </div>
          )}

          {selectedBloodRequest && (
            <div className="fixed inset-0 z-50 overflow-hidden">
              <div className="absolute inset-0 bg-gray-900/40 dark:bg-neutral-950/60 backdrop-blur-sm transition-opacity" onClick={() => setSelectedBloodRequest(null)} />
              <div className="absolute inset-y-0 right-0 max-w-full flex">
                <div className="w-full md:w-[500px] bg-white dark:bg-neutral-900 shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
                  <div className="px-6 py-4 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between bg-gray-50 dark:bg-neutral-900/80 z-10">
                    <div>
                      <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center"><HeartPulse size={18} className="mr-2 text-red-500" /> Request Details</h2>
                      <p className="text-sm text-gray-500 dark:text-neutral-400 mt-1">ID: NSU-EMG-{selectedBloodRequest.id}</p>
                    </div>
                    <button onClick={() => setSelectedBloodRequest(null)} className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-neutral-300 rounded-full hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors"><X size={20} /></button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-6">
                    <div className="flex items-start justify-between mb-8">
                      <div>
                        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">{selectedBloodRequest.hospital}</h1>
                        <p className="text-sm text-gray-500 dark:text-neutral-400 flex items-center mt-1.5"><MapPin size={14} className="mr-1.5" /> {selectedBloodRequest.location}</p>
                      </div>
                      <StatusIndicator status={selectedBloodRequest.status} />
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-8">
                      <div className="flex items-center p-4 bg-red-50 dark:bg-red-500/10 rounded-lg border border-red-100 dark:border-red-500/20"><Droplet size={24} className="text-red-500 mr-3" /><div><p className="text-xs font-semibold text-red-800 dark:text-red-300 uppercase">Blood Group</p><p className="text-xl font-bold text-red-600 dark:text-red-400">{selectedBloodRequest.bloodGroup}</p></div></div>
                      <div className="flex items-center p-4 bg-gray-50 dark:bg-neutral-800/50 rounded-lg border border-gray-100 dark:border-neutral-800/50"><Activity size={24} className="text-gray-400 dark:text-neutral-500 mr-3" /><div><p className="text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase">Required</p><p className="text-lg font-bold text-gray-900 dark:text-white">{selectedBloodRequest.units} Unit(s)</p></div></div>
                    </div>
                    <div className="mb-8">
                      <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-3 border-b border-gray-200 dark:border-neutral-800 pb-2">Description & Notes</h3>
                      <p className="text-sm text-gray-600 dark:text-neutral-300 leading-relaxed bg-yellow-50/50 dark:bg-yellow-900/10 p-4 rounded-lg italic border border-yellow-100 dark:border-yellow-900/30">"{selectedBloodRequest.notes}"</p>
                    </div>
                  </div>
                  {selectedBloodRequest.status === 'Active' ? (
                    <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
                      <div className="grid grid-cols-2 gap-3">
                        <button className="flex justify-center items-center px-4 py-2.5 border border-red-200 dark:border-red-900/50 rounded-lg text-sm font-bold text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 transition-colors"><Ban size={18} className="mr-2" /> Remove</button>
                        <button className="flex justify-center items-center px-4 py-2.5 rounded-lg text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"><CheckCircle2 size={18} className="mr-2" /> Mark Resolved</button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-gray-50 dark:bg-neutral-900/80 text-center"><p className="text-sm text-gray-500 dark:text-neutral-400 font-medium flex items-center justify-center"><CheckCircle size={16} className="mr-1.5 text-emerald-500" /> Resolved.</p></div>
                  )}
                </div>
              </div>
            </div>
          )}

          {selectedDonor && (
             <div className="fixed inset-0 z-50 overflow-hidden">
             <div className="absolute inset-0 bg-gray-900/40 dark:bg-neutral-950/60 backdrop-blur-sm transition-opacity" onClick={() => setSelectedDonor(null)} />
             <div className="absolute inset-y-0 right-0 max-w-full flex">
               <div className="w-full md:w-96 bg-white dark:bg-neutral-900 shadow-xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
                 <div className="px-6 py-4 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between bg-gray-50 dark:bg-neutral-900/80">
                   <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Donor Profile</h2>
                   <button onClick={() => setSelectedDonor(null)} className="text-gray-400 hover:text-gray-500 dark:hover:text-neutral-300"><X size={20} /></button>
                 </div>
                 <div className="flex-1 overflow-y-auto p-6">
                   <div className="flex flex-col items-center text-center mb-8">
                     <img className="h-24 w-24 rounded-full border-4 border-white dark:border-neutral-800 object-cover" src={selectedDonor.avatar} alt="" />
                     <h3 className="mt-4 text-xl font-bold text-gray-900 dark:text-white">{selectedDonor.name}</h3>
                     <div className="mt-3 flex items-center gap-2">
                       <Badge type={selectedDonor.role}>{selectedDonor.role}</Badge>
                       <span className="inline-flex items-center justify-center px-2 py-0.5 rounded bg-red-100 text-red-700 font-bold text-xs dark:bg-red-500/20 dark:text-red-400 border border-red-200 dark:border-red-500/30">{selectedDonor.bloodGroup}</span>
                     </div>
                   </div>
                   <div className="space-y-4 border-t border-gray-200 dark:border-neutral-800 pt-6">
                     <h4 className="text-xs font-semibold text-gray-500 dark:text-neutral-400 uppercase mb-2">Donation Details</h4>
                     <div className="flex items-start"><MapPin size={18} className="text-gray-400 dark:text-neutral-500 mt-0.5 mr-3" /><div><p className="text-sm font-medium text-gray-900 dark:text-white">Preferred Location</p><p className="text-sm text-gray-500 dark:text-neutral-400">{selectedDonor.location}</p></div></div>
                     <div className="flex items-start"><Clock size={18} className="text-gray-400 dark:text-neutral-500 mt-0.5 mr-3" /><div><p className="text-sm font-medium text-gray-900 dark:text-white">Last Donation</p><p className="text-sm text-gray-500 dark:text-neutral-400">{selectedDonor.lastDonation}</p></div></div>
                   </div>
                 </div>
                 <div className="p-6 border-t border-gray-200 dark:border-neutral-800 bg-gray-50 dark:bg-neutral-900/80">
                   <button className="w-full flex justify-center items-center px-4 py-2 border border-red-200 dark:border-red-900/50 rounded-lg text-sm font-medium text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 transition-colors"><Ban size={18} className="mr-2" /> Remove Entry</button>
                 </div>
               </div>
             </div>
           </div>
          )}

          {selectedAd && (
            <div className="fixed inset-0 z-50 overflow-hidden">
              <div className="absolute inset-0 bg-gray-900/40 dark:bg-neutral-950/60 backdrop-blur-sm transition-opacity" onClick={() => setSelectedAd(null)} />
              <div className="absolute inset-y-0 right-0 max-w-full flex">
                <div className="w-full md:w-[700px] bg-white dark:bg-neutral-900 shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
                  <div className="px-6 py-4 border-b border-gray-200 dark:border-neutral-800 flex items-center justify-between bg-white dark:bg-neutral-900 z-10">
                    <div>
                      <h2 className="text-lg font-semibold text-gray-900 dark:text-white">{selectedAd.isNew ? 'Create New Campaign' : 'Edit Campaign'}</h2>
                      <p className="text-sm text-gray-500 dark:text-neutral-400">{selectedAd.isNew ? 'Draft a new promotional poster banner' : `ID: NSU-AD-${selectedAd.id}`}</p>
                    </div>
                    <button onClick={() => setSelectedAd(null)} className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-neutral-300 rounded-full hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors"><X size={20} /></button>
                  </div>

                  <div className="flex-1 overflow-y-auto p-6 space-y-8">
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <label className="block text-sm font-semibold text-gray-900 dark:text-white">Poster Preview</label>
                        <span className="text-xs text-gray-500 dark:text-neutral-400 font-medium bg-gray-100 dark:bg-neutral-800/50 px-2 py-1 rounded">Landscape Ratio (21:9)</span>
                      </div>
                      <div className="w-full aspect-[21/9] bg-gray-50 dark:bg-neutral-950 rounded-xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 dark:border-neutral-700 relative overflow-hidden group hover:border-blue-400 dark:hover:bg-neutral-900 transition-colors">
                        {selectedAd.img ? (
                          <><img src={selectedAd.img} alt="Preview" className="w-full h-full object-cover transition-opacity group-hover:opacity-60" /><div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><button className="px-4 py-2 bg-white dark:bg-neutral-800 text-gray-900 dark:text-white font-medium rounded-lg shadow-sm flex items-center"><Upload size={16} className="mr-2" /> Change Image</button></div></>
                        ) : (
                          <div className="text-center p-6"><div className="w-12 h-12 bg-white dark:bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-3 border border-gray-200 dark:border-neutral-700"><Upload size={20} className="text-blue-500" /></div><p className="text-sm font-medium text-gray-900 dark:text-white">Click to upload poster image</p></div>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <div className="md:col-span-2">
                          <label className="block text-sm font-medium text-gray-700 dark:text-neutral-300 mb-1.5">Campaign Title</label>
                          <input type="text" defaultValue={selectedAd.title} className="w-full px-3 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g., Spring 2026 Admissions" />
                       </div>
                       <div className="md:col-span-2">
                          <label className="block text-sm font-medium text-gray-700 dark:text-neutral-300 mb-1.5">Internal Notes</label>
                          <textarea rows="3" defaultValue={selectedAd.notes} className="w-full px-3 py-2 border border-gray-300 dark:border-neutral-700 rounded-lg bg-white dark:bg-neutral-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" placeholder="Add tracking references..." />
                       </div>
                    </div>
                  </div>

                  <div className="p-5 border-t border-gray-200 dark:border-neutral-800 bg-gray-50 dark:bg-neutral-900/80 flex items-center justify-end gap-3">
                     <button onClick={() => setSelectedAd(null)} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-neutral-200 bg-white dark:bg-neutral-800 border border-gray-300 dark:border-neutral-600 rounded-lg hover:bg-gray-50 dark:hover:bg-neutral-700 transition-colors">Cancel</button>
                     <button onClick={() => setSelectedAd(null)} className="px-5 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                        {selectedAd.isNew ? 'Create Campaign' : 'Save Changes'}
                     </button>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </>
  );
};

export default App;